# Changelog

This document records the major changes of the rhwp project.

> 한국어 버전은 [CHANGELOG.md](CHANGELOG.md) 를 참조하세요.

## [Unreleased]

## [0.9.0]

This release introduces PDF import into editable documents, Rust/CLI consumption contracts, and accumulated editing, layout and serialization improvements. See the [GitHub Release](https://github.com/edwardkim/rhwp/releases/tag/v0.9.0) for publication time and distribution artifacts.

### PDF and developer onboarding

- Import PDF into Document IR and save HWP/HWPX via CLI, Rust, WASM or Studio. Select source pages and choose `fidelity` or `editable` layout; inspect table-inference diagnostics ([#7913](https://github.com/edwardkim/rhwp/pull/7913), [#8120](https://github.com/edwardkim/rhwp/pull/8120)).
- Default JBIG2, JPEG 2000, ICC conversion and bounded xref recovery, request policies, Linux CLI isolation and browser Worker cancellation/recovery ([#8181](https://github.com/edwardkim/rhwp/pull/8181), [#8190](https://github.com/edwardkim/rhwp/pull/8190), [#8360](https://github.com/edwardkim/rhwp/pull/8360)).
- Pattern images and text outlines, supported curved clipping, rotated text and masks; Standard Security R2–R6 password authentication and source-page/total-page progress ([#8410](https://github.com/edwardkim/rhwp/pull/8410), [#8420](https://github.com/edwardkim/rhwp/pull/8420)).
- A usable import dialog: selection no longer retains the busy cursor; advanced JSON no longer dominates the default screen ([#8401](https://github.com/edwardkim/rhwp/pull/8401), [#8412](https://github.com/edwardkim/rhwp/pull/8412)).
- **[PDF developer quick start](mydocs/manual/pdf_developer_onboarding_EN.md)** covers builds, first conversion, passwords, Rust/WASM, Worker hosting, progress and error recovery.

### Editing, layout and round trips

- Corrections to nested/RowBreak tables, stored lines, padding, inline objects, headers/footers, equations and font fallback, integrated with original contributor history and verification evidence.
- Pictures in table cells and relocation across pages with Undo/Redo, continuous highlighting, nested paragraph formatting, logical editing and multi-column reflow ([#8725](https://github.com/edwardkim/rhwp/pull/8725), [#8379](https://github.com/edwardkim/rhwp/pull/8379), [#8340](https://github.com/edwardkim/rhwp/pull/8340), [#8187](https://github.com/edwardkim/rhwp/pull/8187)).
- Better preservation of text-box vertical alignment, captions, definition slots, BinData references, pictures and solid fills after saving/reopening ([#8309](https://github.com/edwardkim/rhwp/pull/8309), [#8711](https://github.com/edwardkim/rhwp/pull/8711), [#8738](https://github.com/edwardkim/rhwp/pull/8738)).
- Preserved container lines, text around inline tables, and header/footer definition slots after HWP/HWPX saving and reopening ([#8741](https://github.com/edwardkim/rhwp/pull/8741)).
- Reduced large-table lookup and equation/JPEG rendering costs, plus handling for slow/unresponsive web fonts. Performance benefits depend on input and environment.

- Includes cell-shape movement, equation font/original-frame preservation and continued-table corrections merged during release preparation ([#8754](https://github.com/edwardkim/rhwp/pull/8754)).
- Memo read/insert/update/delete APIs, HWP/HWPX round trips, author/creation-time preservation, and Undo/Redo for anchor-text deletion in Studio. A new memo UI remains separate work ([#8269](https://github.com/edwardkim/rhwp/pull/8269)).

### CLI, packaging and Native hosts

- Sixel and Kitty graphics with document-font guidance ([#7829](https://github.com/edwardkim/rhwp/pull/7829), [#8154](https://github.com/edwardkim/rhwp/pull/8154)). Official CLI archives use `native-skia` and execute a PNG packaging smoke test, addressing its absence from v0.8.7 official archives ([#7818](https://github.com/edwardkim/rhwp/pull/7818)).
- **crates.io distribution begins with 0.9.0.** Rust developers can add `rhwp = "0.9.0"`; CLI users can install with `cargo install rhwp --version 0.9.0 --locked --bin rhwp` once published. Initial publication and consumption from the public registry are release completion requirements for the 14-package graph, using Rust 1.93.1. Installation becomes available when version 0.9.0 is published to the relevant registry.
- Native snapshots, tiles, caches and Qt/Flutter host foundations. macOS Metal remains disabled-by-default experimental infrastructure awaiting Apple SDK validation; this is not a claim of a complete cross-platform GPU editor ([#8739](https://github.com/edwardkim/rhwp/pull/8739)).
- Image insertion in exam ingest and agent/MCP guidance ([#8499](https://github.com/edwardkim/rhwp/pull/8499)).
- Separated password authentication from diagnostic flows and redacted Debug output without disabling CodeQL. A protected-branch full security scan remains a separate follow-up ([#8750](https://github.com/edwardkim/rhwp/pull/8750)).

### Compatibility and limits

PDF import does not reconstruct every authoring structure or OCR scans. Unsupported clipping, masks, text paint and encryption combinations remain explicit errors. Custom limits only lower profile ceilings. Complete parser heap/RSS bounds are not proven; synchronous APIs require host cancellation/isolation. Imported documents do not inherit the source PDF password.

Other editors may render RHWP text-paint extensions or transparent PNGs differently. Supply actual fonts and verify target-application output. Pin JS/WASM, Workers and hosted Studio together. VS Code retains HWP/HWPX file associations.

### Contributors

The audit covers 4,896 commits after v0.8.7 through the release finalization baseline `41e08ae19e360a32179d851ca2534c1195a8dced`, including authors, co-authors, original PRs and cherry-pick origins. It identifies 33 people and one separately credited bot (Dependabot), with zero unresolved human identities or reference dispositions. Nine unavailable cherry-pick source objects are disclosed; integrated commit authors remain included. Verify that release-record changes after this baseline introduce no uncredited authors.

[Contributor ledger](mydocs/tech/investigations/release-v0.9.0/contributor-ledger.json) · [Identity evidence](mydocs/tech/investigations/release-v0.9.0/contributor-overrides.json)

<!-- release-contributors:v0.9.0:start -->
- @9ood2s
- @ashcastle
- @bellkjtt
- @chrisryugj
- @davindev
- @donggyun112
- @edwardkim
- @emptinessform
- @greenoceanplanet
- @h1-andro2d
- @hccgahy1-hub
- @hexisteme
- @hyunmyungJaneLee
- @jangster77
- @jeong-sik
- @johndoekim
- @Kang-T
- @ldj-diquest
- @lidge-jun
- @mytrashcan
- @oksure
- @pblsketch
- @Phantomn
- @physwkim
- @planet6897
- @postmelee
- @sacru2red
- @scari
- @semanticist21
- @seo-rii
- @Steveyang8282
- @studyreadbook4ever
- @wook8170
<!-- release-contributors:v0.9.0:end -->

---

## [0.8.7] — 2026-10-06

> Cumulative PATCH release measured from 2,395 commits and provenance for 230 PRs after v0.8.6 through
> feature baseline `17a69fa4e`. Later main-history reconciliation, versioning and distribution evidence are
> tracked separately from that measured range.

### Typesetting, rendering, and fonts

- Preserve stored line membership, available width and outer margins for consecutive inline TAC tables.
  Reflow without stored LineSegs distinguishes tables sharing a line from width-driven line breaks (#7482, #7585).
- Preserve empty physical bands, cell padding and content ownership across rowspan/nested-table page splits,
  including the preceding fragment border, continued pictures and following paragraphs (#7368, #7567, #7570).
- Correct edited-paragraph indentation and line placement before TAC tables (#7599).
- Connect host font providers and explicit font environments to measurement, CanvasKit and Canvas2D output,
  and strengthen atomic fallback for native exact glyph replay (#6881, #7179, #7405).

### Opening, saving, and editing

- Fix Hancom opening of HWP5 documents with empty headers/footers, preserve repeating table headers and
  page-boundary options, and normalize fallback HWPX layoutCompatibility output (#7338, #7460, #7478).
- Add English Studio UI, editable web hyperlinks preserved in HWP/HWPX/PDF, overwrite mode and search
  result counts (#6984, #7318, #7485, #7493).
- Correct Enter after tables, empty-paragraph/page ownership, caret/scroll behavior, and nested-table
  selection, deletion and clipboard boundaries (#7487, #7539, #7601).
- Add CLI table column-width/alignment/field-placement options, safe block copy/fill/cross-document import,
  and caption/header/footer address metadata (#7038, #7068, #7101).

### Input safety and browser extensions

- Harden SVG font CSS/XML boundaries, IPv4-mapped IPv6 classification, HWP3 paragraph depth, linked-image
  file types and cumulative XML read budgets. Restore normal raw-DEFLATE thumbnails using the browser's
  standard format label (#7602).
- Harden WMF integer-extreme arithmetic and bitmap bounds. The release includes the defense against the
  text-spacing subtraction panic still reported by scheduled fuzzing on the older main tree (#7263).
- Fix Chrome download-completion events during initial state persistence, Firefox duplicate/reopened
  download tabs and path exposure in automatically opened document filenames (#6965, #6966, #7279).

### macOS, packages, and distribution

- Move macOS CLI builds to `macos-15`: native ARM64 and cross-compiled Intel builds on Apple Silicon,
  with target/runner-specific cache keys that avoid reusing older SDK artifacts (#7556).
- Stable-tag Release Binary directly calls npm, VS Code Marketplace and Open VSX publishing from the same
  commit, with independent exact-version checks and aggregate evidence (#6799).
- Align Rust, npm core/editor, Studio, VS Code and Chrome/Edge/Firefox/Safari at 0.8.7.
  Chrome, Edge and Firefox packages are submitted through their respective stores.

### Compatibility and remaining scope

- Keep the existing JSON envelope major and explicit font/compatibility opt-ins.
- Harden implementation input boundaries without claiming to resolve every vulnerability in the HWP/HWPX
  formats. Separate investigations and private advisory/CVE work continue on their own tracks.
- Safari's manifest version is aligned; this store-distribution cycle covers Chrome, Edge and Firefox.

### Contributors

The measured feature baseline includes 29 human contributors, sorted without changing handle case.
Bots and AI co-authors are counted separately.

<!-- release-contributors:0.8.7:start -->
- @aodtjddms
- @baba9811
- @davindev
- @edwardkim
- @emptinessform
- @humdrum00001010
- @jangster77
- @jeong-sik
- @kyunghwan-AITeam
- @lidge-jun
- @LJYeon12
- @lpaiu-cs
- @moongioh
- @nishantpurohit04
- @planet6897
- @postmelee
- @rubidus-api
- @salgum1114
- @semanticist21
- @semo-git
- @seo-rii
- @seongeun82
- @spamcam1207-stack
- @winchoose
- @yoonkhsc
- @z0rimo
- @zer0bi9
- @zlzlzlmo
- @zunstudio
<!-- release-contributors:0.8.7:end -->

## [0.8.6] — 2026-09-02

> Cumulative PATCH release prepared from provenance for 262 PRs found in the 2,214-commit feature baseline
> after v0.8.4. Later versioning, validation, and release-record commits are tracked separately from that measured
> range. It improves document fidelity, Studio editing, CLI and agent surfaces, input safety, and release
> reliability while keeping the existing JSON envelope major.

### Typesetting, rendering, and fonts

- Added `HwpDocument.setExactFontInstance(optionsJson)` and `clearExactFontInstance(optionsJson)`. They apply
  `boundedHorizontalLtrV1` variable-font requests only to exact slots registered by the host, with strict JSON
  validation and idempotent per-slot clearing. Axes are never inferred from parser data or font names (#4969).
- Connected exact-font kerning, bounded common-shaping replay, and vertical layout to the typesetting and
  CanvasKit paths in guarded stages. Unsupported or malformed inputs retain the established safe fallback.
- Fixed page ownership and placement for stored RowBreak tables, physical frames, LineSegs, space-taking
  objects, table widths, text-box vpos, superscript advance, empty-line TAC pictures, and overlapping Square
  pictures against Hancom oracle output.
- Added opt-in `--compat 2024` handling for Hancom 2024 table-anchor line accounting. The default policy does
  not switch merely because of a version number (#5525).

### Open, save, and round-trip preservation

- Preserve `hp:ole` shape-component children (`offset`, `orgSz`, `curSz`, `flip`, `rotationInfo`,
  `renderingInfo`, and `lineShape`) plus `id`/`instid`. A zero `curSz` is restored through its sentinel and
  negative offsets retain the required u32 wraparound (#4669, #5450).
- Serialize HWPX curves as `hp:seg` chains to prevent Hancom open crashes, and recover pictures when BinData
  storage IDs contain gaps (#4676, #3893, #4049).
- Fixed HWP3 section-control placement and character preservation, plus save paths that could lose body text
  through OWPML enums, hidden descriptions, or placeholder ranges (#4680, #4776).
- Open HWPML documents that include a DOCTYPE or declare Version 2.1 (#5848).
- Nested-table search and replace now emits `cellPath` at depth two and beyond while preserving the existing
  depth-one `cellContext` envelope (#2792).

### Editing, Studio, and browser extensions

- Added whole-document HTML and Word `.doc` export plus numeric chart-data editing UI.
- Fixed Korean IME `Ctrl+A`, document/recent-file names after Save As, header/footer selection and editing APIs,
  validated zoom application, and standard print-paper snapping.
- Improved mouse resizing for merged and ordinary table borders, caret reveal after page breaks, and ruler
  updates.
- Prevented `.xlsx` downloads from being incorrectly opened by the HWP viewer in the Chrome extension (#6547).

### CLI, agents, and MCP

- Expanded editing and query commands and consolidated Control/document queries in `rhwp-q-pack`.
- Added a public document-agent command bridge and an HWP 2024 remote MCP client.
- Reworked the CLI help index and per-command help, and made `test-caption` reject unverified success.

### Security, performance, and operations

- Bounded HWPX-container and parser recursion, and hardened input boundaries and WMF initialization.
- Oracle PDF auto-selection now fails closed when format, producer, or saving product is ambiguous.
- Reused exact-font sources and variable-shaping caches within bounded owners, and reduced repeated CI work
  through nextest archive partitioning, split CodeQL paths, and documentation/review-only evidence reuse.
- Restored trusted-controller reuse for identical merge trees. The live post-release Render Diff canary remains
  tracked in #6243.

### Packages and distribution

- Added a native `aarch64-unknown-linux-gnu` target to the GitHub Release CLI matrix (#5949, #6573).
- Fixed Docker image builds when the requested GID is already in use (#5758).
- Align Rust, `@rhwp/core`, `@rhwp/editor`, Studio, VS Code, and Chrome/Edge/Firefox/Safari at version 0.8.6.

### Compatibility and known follow-ups

- Exact-font instances and `--compat 2024` are explicit opt-ins. Existing defaults and the JSON envelope major
  remain unchanged.
- Re-saving may produce different bytes where preservation bugs were repaired; those changes restore document
  meaning rather than introduce a format break.
- Issue #5949 remains open until the real v0.8.6 Linux AArch64 asset passes ELF, executable-bit, and version
  checks.
- Issue #6243 remains open until the trusted controller passes a real post-release canary on `main`.

### Contributors

Twenty people contributed during this cycle (credit keys, case-preserving alphabetical order):

<!-- release-contributors:start -->
- @chrisryugj
- @coolwithyou
- @davindev
- dkh0324 — Git author credit; no public GitHub account confirmed
- @edwardkim
- @humdrum00001010
- @JamesPsh
- @jangster77
- @jeong-sik
- @johndoekim
- @keepYaoung
- @kevin9327
- @kjh0523
- @lpaiu-cs
- @planet6897
- @postmelee
- @RaghavShubham
- @Shadungi
- @t2c-lab
- @thhan74
<!-- release-contributors:end -->

## [0.8.4] — 2026-08-12

### Distribution surface rollback

- Restored the official distribution surface to the v0.8.2 set: GitHub Pages,
  native CLI archives on GitHub Releases, npm `@rhwp/core` and `@rhwp/editor`,
  VS Code Marketplace/Open VSX, and the Chrome, Edge, and Firefox extensions
  remain supported (#4655).
- Removed the PyPI, `@rhwp/node`, GHCR CLI image, deb/rpm/MSI, install scripts,
  package-manager manifests, and setup GitHub Action paths that had been added
  without explicit maintainer adoption and complete safety validation (#4655).
- Removed the dedicated Python and Node binding source, tests, and current-use
  documentation together with those withdrawn channels. A new official channel
  now requires agreed build, install, update, rollback, and ownership evidence.

## [0.8.3] — 2026-08-11

> Cumulative PATCH release integrating 190 PRs since v0.8.2. It expands
> encrypted-document open/save support, nested-table layout and editing,
> MCP/agent execution contracts, official Node/Python bindings, and
> multi-platform distribution. The existing JSON envelope major remains 1.0.

### Encrypted documents and save compatibility

- Open HWP5 EncryptVersion 4 documents with a Studio password prompt
  (#3405, #3477).
- Added HWP3 decryption and encrypted HWPX opening, with stronger preservation
  of archaic Hangul strings in HWP3 (#3483, #3516).
- Added encrypted save-and-reopen contracts for HWP3, HWP5, and HWPX (#3690).
- Expanded fixes for corrupt HWP5 save paths and HWPX namespace, OLE, tab, and
  chart round-trip preservation.

### Typesetting and rendering fidelity

- Continued fixes for nested-table pagination, RowBreak, empty cell paragraphs,
  child-table flow, and the final bottom border (#4094, #4122, #4174, #4517,
  #4525, #4567).
- Restored square-number and small right-triangle glyphs encoded through PUA
  character overlap (#4139, #4227, #4228).
- Added exact CanvasKit glyph-run replay and improved page-number metrics and
  replay determinism (#3741).

### Editing, Studio, and VS Code

- Fixed nested-table text/table selection and copy paths, and expanded
  multi-cell formatting (#4119, #4267, #4276).
- Added three-mode F5 table-cell resizing, table split/join, and a font-style
  no-op fix (#3771, #3831, #4271).
- Added VS Code document-outline navigation (#4093).
- Expanded the HwpCtrl-compatible surface and compatibility ledger in stages
  (#4187, #4274, #4486).

### CLI, MCP, and agent contracts

- `mcp-serve` now provides a stdio JSON-RPC server with document session handles
  (#3571).
- Added IR/capabilities/plan schemas, ontology, provenance, replay/lineage/audit,
  signing, anchor/gate, security diagnostics, and a validation ladder. The
  `capabilities` schema registry self-describes envelope 1.0, IR 1.0,
  capabilities 1.3, and plan 1.1 (#4574).
- `run` plans and capsules bind input, plan, and output hashes; optional CAS
  preconditions can reject changed input before execution.
- Added official Node and Python bindings plus generated-type drift checks.

### Security and performance

- Bounded decompression output to prevent memory exhaustion from deflate-bomb
  inputs (#4263).
- Reduced cursor, selection, local repaint, duplicate-render, and post-edit
  rerender costs for large tables (#3672, #3745, #4156, #4265).
- Integrated Subsecond hotpatch invalidation, diagnostics, lifecycle, and repaint
  boundaries (#4602).

### Packages and distribution

- Added GitHub Release CLI archives for Linux x86_64, macOS x86_64/arm64, and
  Windows x86_64, with `SHA256SUMS.txt`.
- Added workflows for Python wheels/sdist, `@rhwp/node`, Debian/RPM/MSI
  installers, and GHCR container images. Channels without publishing secrets or
  packaging prerequisites validate and then skip publication explicitly.
- Added cargo-binstall asset mapping, install.sh/install.ps1, and initial
  Scoop/Homebrew/Winget/AUR channels. Hash-based manifests are updated only after
  release assets exist.
- Hardened CI with pinned action SHAs, stale-run cancellation, cache-generation
  cleanup, and path-aware execution.

### Contributors

Sixteen people contributed during this cycle (GitHub handles, alphabetical):

- @edwardkim, @enigma-jerry72, @humdrum00001010, @JamesPsh, @jangster77, @jeong-sik,
  @johndoekim, @kevin9327, @lpaiu-cs, @NacreousCloud, @planet6897, @postmelee,
  @scari, @seo-rii, @walnutkim, @yuyu04

## [0.8.2] — 2026-07-27

> Hotfix — restores printing in the browser extensions, which had been broken
> since v0.8.0.

### Extension printing restored
- **Fixed printing failing with "file not found" in the browser extensions
  (Chrome, Edge, Firefox).** The print preview document (`print.html`) was not
  included in the extension build output; it was omitted from the build copy list
  when the print path was introduced in v0.8.0 (#3433).
- Added a required-artifact gate to the extension builds. Previously a failed
  asset copy only produced a warning and the build still succeeded, so the
  omission went unnoticed. The build now fails when a runtime-required file is
  missing.

### Rendering correction
- Wired left/right outMargin into the x-origin of TAC inline tables to match
  Hangul character rules (#3396).

### Known issues
- The studio E2E `print-pdf-issue3126` PDF guidance modal assertions fail. The
  print surface itself works; the failure originates outside this release's scope
  and its root cause is not yet diagnosed (#3450).
- The studio E2E `issue-2214` page-local repaint contract failure carries over
  from v0.8.1; whether it is a regression remains undetermined (#3412).

## [0.8.1] — 2026-07-26

> PATCH release — rendering corrections and CLI contract consistency since
> v0.8.0. New features are included but are confined to the CLI tooling layer;
> there are no public library API changes.

### Rendering corrections
- Header objects placed on the master page (page-number boxes, labels) no longer
  overflow past the side margins to the physical paper edge — the horizontal
  reference area for paragraph/column-anchored objects is corrected to the body
  text area, matching Hancom output (#3402).
- HWP 3.0: page 1 WordArt now renders without a sidecar file — the embedded OLE
  payload (pic_type=1, additional info block id=2), previously misread as an
  externally linked image, is extracted, repackaged, and drawn from its OlePres000
  WMF preview. WMF POLYPOLYGON hole loss is also corrected (single path merge)
  (#3363).
- HWP 3.0: paragraph borders set to "no line" no longer render as solid lines —
  wiring now follows Hancom's measured mapping. Shading side rules share the same
  root cause and are corrected together (#3303).

### CLI — contract consistency
- Unified positional argument parsing across `export` commands — svg/png/pdf/
  markdown/render-tree/doclang (#3359); `export-text` accepts option-first
  invocation (#3349).
- `search --limit` truncation is now visible — added `totalMatchCount` and
  `truncated` (#3353).
- `thumbnail` exit-code consistency — removed the behavior of ignoring unknown
  options and returning exit 0 (#3366).
- `capabilities` now self-describes `export-png` feature availability via
  `requiresFeature`/`available` (#3357); `edit` commands are registered in
  capabilities and MCP self-description (#3329).
- ingest rejects unknown fields — immediate failure with position and hint
  instead of silent data loss (#3358).
- `build-from-ingest` now specifies a borderless default borderFill, removing
  boxes drawn around every text run (#3355).

### CLI — new features
- `edit fill-fields` for filling form values (#3329), `edit replace-text` for
  document-wide replacement (#3373), `edit set-cell` for writing cells by table
  grid coordinates (#3381).
- Added search, export-tables, and fields axes to `batch` (#3346).
- Standard government form assets — General Draft Form (Form No. 1) and Simplified
  Draft Form (Form No. 2), with 23 form fields and contract tests (#3372).
- Large-scale page-by-page comparison harness against Hancom official PDF
  references (#3389).

### studio
- Style creation, modification, and deletion are now recorded in the edit history;
  previously they bypassed the edit router and could not be undone with `Ctrl+Z`.
  Deletion is recorded as a snapshot because it reassigns style_id document-wide
  (#3387).
- Guarded the dev-only fetch for externally linked images in production and
  extension builds, removing extension Errors noise (#3348).

### Dependencies
- base64 0.22.1 → 0.23.0, snafu 0.9.1 → 0.9.2.
- Seven GitHub Actions major updates — checkout v7, setup-node v7, cache v6,
  upload-pages-artifact v5, deploy-pages v5, github-script v9, action-gh-release v3.

### Known issues
- The studio E2E `issue-2214` page-local repaint contract fails at the
  `after-56-sync` checkpoint (cumulative wasmFlush 2, expected 0). No comparison
  against v0.8.0 was performed, so whether this is a regression remains
  undetermined; tracked separately (#3412).

## [0.8.0] — 2026-07-26

> MINOR release — 265 PRs integrated since v0.7.19. Save round-trip preservation
> overhaul (invalidation contract + dozens of HWPX/HWP5 attribute round-trips),
> new agent-facing CLI query/verification tool suite, parser fuzzing
> infrastructure, editing-undo fidelity series, and rendering/font consistency
> improvements. Starting with this release, **browser extension versions
> (Chrome/Edge/Firefox/Safari) are unified with the library version**
> (0.2.8 → 0.8.0).

### Save reliability — round-trip preservation overhaul
- Fixed a batch of invalidation omissions where edits reverted to stale bytes on
  save — form values, bookmarks, click-here fields, style edits, neighbor-cell
  borders, equation properties, pasted HTML formatting, and more (the
  raw_stream/raw_data invalidation contract is now a canonical document).
- Dozens of HWPX save round-trip preservations: secPr grid/startNum/tabStop,
  table allowOverlap, vertical writing, borderFill threeD/shadow, 7 imgBrush
  modes, lineShape arrowheads, 3-state checkboxes, memo border lineType,
  paragraph numFormat literals, fieldBegin/fieldEnd fieldid, bullet paraHead,
  caption vertAlign, refList memoProperties, object locks, and more.
- HWP5 save-loss fixes — paragraph number format, autoTab bit, shape captions,
  footnote/endnote decorations, BinData remap for caption images in hwpx→hwp.

### CLI — agent tool suite
- 8 JSON query/verification tools integrated: `info` / `export-text --json` /
  parallel batch streaming, `export-structure`, `capabilities`,
  `ir-diff --json` verdict envelope, `export-tables` (grid JSON), `fields`,
  `search` (addressed results), `export-svg --json` (render manifest).
- `export-doclang` — export HWP/HWPX to DocLang v0.6 XML.
- Established non-zero exit-code contract on failure; fixed `export-png` /
  `export-pdf` missing external-linked image loading (#3302).

### Parser robustness — fuzzing and defenses
- Introduced cargo-fuzz parser fuzzing infrastructure (stage 1) and extended
  WMF / ooxml_chart harnesses (stage 2).
- Hardened against malicious/corrupt inputs: WMF region sign-extension panic,
  EMF POINTS16 unchecked allocation, 68 GB table-grid allocation, CFB corrupt
  header panic, DIB over-allocation, infinite-loop/overflow defenses.
- HWP3 IR wiring series — footnote options, separator length/margins,
  between-notes spacing (×4 scale, footnote-only, grounded in Hancom's own
  HWP3→HWPX conversion), TOC-mark separation, bookmark under-read, has_border.

### Editing — undo fidelity series
- Footnote/endnote/equation insertion and header-footer structural operations
  are now recorded in history (#3207).
- Cell paragraph-merge undo restores paragraph-scope properties in table
  cells / text boxes / captions / nested tables (#2342 completed).
- Header/footer fields separate display text from model offsets — caret, undo,
  extraction, and render-tree JSON consistency (#3216).

### Rendering consistency
- Trust stored anchor-lines in para-float stacks — resolved bottom-aligned
  overlap and +1 over-splitting (#2813).
- Removed environment-dependent font sourcing paths and completed Web Canvas
  base-family fallbacks — 10k survey r23 establishes a font-clean baseline
  (zero page-count regressions).
- Hanyang/Human-family ASCII metric calibration, repeated table-header grid
  alignment, TAC margin double-add fix, overlapping-image clip fix, 3D/ofPie
  chart rendering, CanvasKit positioned-text replay.

### rhwp-studio
- Responsiveness and Korean input latency improvements; memoized image
  conversion results.
- Input validation pass — ~20 clamp fixes across dialogs/toolbar plus
  name-length guards preventing record corruption.
- External-linked image display, HWPX OLE object selection, host save
  notification API `notifySaved`, IME/grid-view fixes.

### Browser extensions
- **Unified versioning**: extension versions now match the library (0.8.0).
- Hardened settings persistence/recovery and auto-open defenses.

### Infrastructure & docs
- svg2pdf determinism patches moved to an rhwp-hosted fork; wasm-pack 0.15.0
  pinned; CI parallelization (Native Skia/test archive, Frontend/Lint) and
  retry hardening. (A self-hosted runner experiment was validated and rolled
  back to hosted runners; the pitfall catalog is preserved in docs.)
- PR review workflow split into conditional guides; serialization invalidation
  contract documented; bulk-PR triage tooling; permanent edit-sweep harness.

### Contributors

200 contributor PRs merged in this cycle (since v0.7.19; GitHub handles,
alphabetical):

- @chrisryugj — permanent edit-sweep harness (#2458), one-command OVR
  self-verification (#2449) *(first contribution — welcome!)*
- @cskwork — embed loadFile dialog deadlock prevention (#2518)
- @donggyun112 — template PrvText placeholder fix (#2388), section start-mark
  migration (#2386) *(first contribution — welcome!)*
- @humdrum00001010 — studio responsiveness / Korean input latency (#3255)
- @jangster77 (Taesup Jang) — 42 integration & review-record PRs: #3216
  header/footer field integration (#3325), conditional PR-review guides
  (#3299), bulk intake integrations
- @johndoekim — 3D / ofPie chart rendering (#2500), host save notification
  `notifySaved` (#2660)
- @kevin9327 — 88 PRs: HWPX/HWP5 save round-trip preservation series
  (batches A–M, G3–G12), HWP3 IR wiring series, WMF/CFB/EMF hardening,
  8 CLI JSON tools (#3304), studio input clamp / dialog sync series
- @lpaiu-cs — 18-PR undo fidelity series: dialog/object history recording
  (#2337–#2378), footnote/endnote/equation & header-footer structural
  recording (#3208), cell-merge paragraph meta restore (#3324),
  header/footer display_text separation (#3323)
- @myeolinmalchi — export-doclang: DocLang v0.6 XML export (#3132)
  *(first contribution — welcome!)*
- @planet6897 (Jaeook Ryu) — 28 PRs: 10k Korean oracle survey r16–r23 series
  (font-clean baseline), para-float anchor-line trust (#3270), crop fallback
  regression restore (#3241), render/layout integrations, font fallbacks
  (#3300/#3314)
- @postmelee (Taegyu Lee) — 13 PRs: wasm-pack 0.15.0 pin / toolchain
  alignment (#2420), repeated table-header grid (#2512), Native Skia cache
  writer recovery (#3123), Chrome extension settings hardening (#2658)
- @seo-rii — CanvasKit series: positioned text replay (#2939),
  document-scoped auto selection (#2394), direct PageLayerTree PDF (#2372)
- @sxngt — embed loadFile `suppressDialogs` option (#2390)
  *(first contribution — welcome!)*

## [0.7.19] — 2026-07-17

> Patch following v0.7.18 — honoring stored geometry signals (intra-paragraph vpos
> reset/rewind) across both render and edit paths, table pagination precision
> (rowspan declared-residual, machine-generated form under-splitting), memory /
> PDF determinism improvements, HML format support, and legacy /web decoupling.
> Public API stays backward compatible — PATCH.

### Rendering fidelity — stored-signal trust lineage
- Promote mid-paragraph vpos 0-reset (page-boundary encoding) to a split point for
  paragraphs starting in non-zero columns — fixes bottom clipping / content loss in
  treatise p2 right column, plus the same defect on p4 (#2320).
- Honor intra-para reset for full-page tac picture + trailing tac table paragraphs and
  remove ghost height accounting — poster attachment document 5→3 pages, matching
  Hangul (#2311).
- Fix tac table height collapse in machine-generated documents without stored
  LINE_SEGs — Jinan form 1→2 pages, market-survey pin 309→312 (toward 315) (#2319).
- Fix under-splitting of two-full-page form-table documents — consume float exclusion
  zones in the table-paragraph path + correct inline misclassification of full-page-scale
  (≥30000HU) TAC tables (#2322).
- Spill small tac TopAndBottom object lines into the bottom page margin — extends the
  stored page-last trust path, r12 OVER+SHAPE oracle +3 (#2137, partial).
- Cap master-page objects at the BehindText plane via master_page provenance —
  master-page content no longer covers body text in studio/skia (#2318).

### Table pagination precision
- Add rowspan merged-cell declared-residual to the last spanned row — convention
  confirmed by measuring Hangul row rules; curriculum-map 380→385 pages. Also re-wrap
  under-stored (single-lineseg over-width) cell paragraphs and port relaxed hard-break
  into the rowspan block offset walk (giant cells only) (#2291/#2237).
- Fix two under-splitting defects in table-dense documents — RowBreak rowspan block
  continuation-residual evaporation + TAC picture paragraph height accounting (#2287),
  plus bottom band-fill offset cut retry (#2097).
- Five fresh-layout measurement fixes matching Hangul + footer lead/margin error
  attribution and instrumentation (#2279).
- 80168 regulatory-analysis 157-page alignment — seven-axis decomposition of the
  cancellation network (#2070); RowBreak large-table density (trailing-space ghost
  lines + aim padding-0) and non-Percent line-spacing 2× scale fix (#2070).
- KBU=1 (character-unit line breaking) line-start prohibition retraction — prevents
  isolated periods at line starts, matching a Hangul 2024 oracle (#2244). Fix inverted
  Korean break-unit semantics (#2185). Recompose abnormal HWPX line metrics (#2093).

### Editing fidelity (rhwp-studio)
- Preserve stored resets (column/page-boundary encodings) and paragraph gaps in the
  edit-path vpos recalculation — fixes multi-column band loss / page-count drift and
  removes 60 spurious page-count changes across a 574-sample edit sweep (#2299).
- Fix invisible continuous input in giant-cell (115-page) documents — targeted
  normalized-state cache coherence invalidation (#2214).
- Clear stale object/table selection refs after undo/redo (#2303); add a real-key
  Ctrl+Z smoke to the undo contract e2e plus a harness modal-residue fix (#2317).
- Preserve table cell clip in the static picture layer (#2228). Overflow view enabled
  by default (#2205 line). File menu "Recent Documents" submenu with meta-only
  records (#2285).

### Render pipeline & fonts
- CanvasKit readiness gate and hardened public opt-in (#2224), proof-gated resource
  replay with failure containment (#2248), refreshed cross-backend diagnostics /
  regression corpus with generalized render-profile plumbing (export-png defaults to
  print-equivalent) (#2297 line).
- Local font multilingual matching with CanvasKit registration (#2227), CanvasKit
  bullet font correction (#2190).
- skia PNG: fix chart RawSvg fragment double-offset clipping via viewBox (#2292) and
  prefer Korean-capable fonts in the fallback chain — restores missing chart text
  (#2293).
- OOXML chart C2a stock HLC rendering with 2D fidelity (#2277, #1431 Track C).
- HWP5 strikeout: whitelist strike shapes instead of trusting bits — avoids
  misreading the 3D-placeholder convention (#2258, spec errata #34).

### Performance, memory, determinism
- Lazy BinData loading — embedded images no longer fully resident at parse time,
  RSS 244MB→49MB (#2263).
- `--text-as-paths` option for the PDF memory dominator (svg2pdf text embedding)
  (#2264); vendored svg2pdf determinism patch for byte-reproducible export-pdf
  (#2269, with font-numbering nondeterminism attribution and a normalize-compare tool).

### Format support
- HML (HWPML) document open + semantics-preserving save (#1157).
- @rhwp/editor MessageChannel embed transport v1 (#2186).

### Frontend infrastructure
- Remove the legacy `/web` dev app (18 entries, 616KB) and its coupling in the CI
  detector / metrics / font contract; non-legacy neutrality proven with function-level
  metrics (#2313).
- assets/fonts as the canonical font root (#2254 line), frontend package build/test CI
  gate (#2183), Phase 0 baseline freeze (#2124, ongoing).

### Tools & docs
- HWP 2020 MCP client long-document timeout sync (#2253), 13th 10k-sample validation
  report (#2262), row-anchor comparison tool (tools/task2287), print-mode CLI manual
  refresh, ongoing PR-review record keeping (jangster77's review-doc series).

### Contributors

55 contributor PRs merged in this cycle (since v0.7.18; GitHub handles, alphabetical):

- @cskwork — HML open/semantics-preserving save (#2219), @rhwp/editor MessageChannel embed transport v1 (#2187)
- @jangster77 (Taesup Jang) — 17 PRs of external-PR integration and review records: local font multilingual matching (#2227), cell clip preservation (#2229), abnormal HWPX line recomposition (#2231), CanvasKit bullet fonts (#2196), MCP timeout (#2255), etc.
- @johndoekim — OOXML chart C2a stock HLC rendering (#2288)
- @lpaiu-cs — edit-path stored-reset preservation (#2314), stale selection refs after undo/redo (#2304), real-key undo e2e smoke (#2324)
- @planet6897 (Jaeook Ryu) — 21 PRs of rendering/pagination fidelity: rowspan declared-residual convention (#2309), the r15 form-stack trilogy (#2315/#2321/#2323), lazy BinData (#2265), svg2pdf determinism (#2281), 10k sample validation (#2262), etc.
- @postmelee (Taegyu Lee) — legacy /web removal (#2316), giant-cell edit cache coherence (#2241), break-unit semantics fix (#2194), canonical font root (#2254), frontend CI gate (#2216/#2235), Phase 0 freeze (#2174)
- @seo-rii — CanvasKit readiness gate (#2224), proof-gated resource replay (#2248), cross-backend diagnostics/profile plumbing (#2297)
- @yeonic (Jongyeon Kim) — HWP5 strikeout strike-shape whitelist (#2258) *(welcome, first contribution!)*

## [0.7.18] — 2026-07-11

> Patch release following v0.7.17 — large-scale rendering fidelity fixes (floating/front
> object pagination, RowBreak tables, endnote flow), huge-table performance, editor
> caret/undo/OLE parity, lenient parsing & expanded HWPX preservation, WMF shape rewrite.
> Includes 21 internal refactoring rounds with zero behavioral regressions. Public API
> remains backward compatible — PATCH.

### Rendering fidelity
- Floating/front object pagination parity: one-image-per-page splitting (#1995/#2004/#2006),
  paper-anchored behind-text tables (#1994), floating-form over-pagination 81→18 pages
  (#2019), nested 1×1 cell content pagination (#2007).
- RowBreak tables: block-cut sliver absorption (#1921), footnote-heavy over-pagination
  (#1937), missing-LINE_SEG cell line-height correction 213→159 pages (#1842),
  declared-fit trust expansion (#2097), vert_offset double-counting (#2015).
- Bottom saved-bounds trust (#2093), page-bottom anchored frame vpos=0 preservation
  (#1920/#2158), Hancom-family Latin/punctuation widths mapped to Haansoft Batang
  metrics (#2156), and more.

### Performance
- Removed O(pages×cell) re-measurement via cell_units memoization (#1949); removed O(n²)
  cell measurement for a 52,694-cell document render timeout (#2063); DocumentCore: Send
  restored via Rc→Arc (#2087).

### Editor (rhwp-studio)
- Caret on late pages: 3,064ms→33ms via page-hint search (#2021). Unified undo snapshot
  routing for find&replace and picture/equation property dialogs (#2037/#2028/#2077).
  OLE selection/caption/paste parity (#2069), table-cell Enter caret fixes (#2164/#1951).

### Parser & serialization
- Lenient decoding fallback for partially corrupted documents (#1932), unregistered
  styleIDRef demotion (#1933), encrypted-HWPX detection (#1946), MAX_XML_SIZE 256MB
  (#1917). HWPX preservation: note shapes (#1984), breakLatinWord (#1986), secPr fields
  (#1987), curSz=0 sentinel (#2017). HWP5 page_def/CommonObjAttr round-trip (#1915/#1916).

### WMF/Shapes
- write_line rewrite fixing connectLine corruption (#1943), legacy drawText emission
  (#1944), shape restrictInPage bottom clamp (#2075), cell-anchored picture
  vertical_align (#2071).

### Internal quality
- 21 complexity-refactoring rounds: max CC 288→117 (−59%), zero behavioral regressions
  across all rounds (#1904/#2131), metric formula v2.1 + reduction-potential scanner
  (#2130), quality dashboard published under mydocs/metrics/.
### Contributors

268 contributor PRs merged this cycle (since v0.7.17), GitHub handles in alphabetical order:

- @humdrum00001010 — HWPX package-graph serialization (#1675), endnote parity (#1875), +3
- @jangster77 (Taesup Jang) — 130 PRs: table/editing parity, external PR integration & reviews, OLE object parity (#2103), long-input caret/IME (#2172)
- @johndoekim — bangjeom rendering (#1738), OOXML chart C1c/C1d (#1890/#1954/#2140), +3
- @kkyu8925 — empty-host co-anchored float table orphan control (#1767), +3 *(first contribution — welcome!)*
- @lpaiu-cs — undo snapshot routing trilogy (#2028/#2039/#2078), restrictInPage clamps (#2033/#2076), BinData id allocation (#2040), cell-anchored picture valign (#2074) *(first contribution — welcome!)*
- @oleg-sung — centered cell paragraph vpos after TAC shape (#1674) *(first contribution — welcome!)*
- @physwkim — cell_units Rc→Arc Send restoration (#2087), new-paragraph format inheritance (#2095)
- @planet6897 (Jaeook Ryu) — 74 PRs: rendering-fidelity series (RowBreak tables, floating/front object pagination, huge-table performance #2063, 10k-document surveys)
- @postmelee (Taegyu Lee) — 28 PRs: CI release-test migration (#1739), frontend refactoring plan v2 (#2080) & Phase 0 baseline (#2174, in progress)
- @seo-rii — CanvasKit object-gap diagnostics (#1806), +2
- @snvtac — endnote reset-rewind column placement (#1495) *(first contribution — welcome!)*

Dependencies: 6 dependabot PRs (including the quick-xml 0.41 security release).


## [0.7.17] — 2026-06-23

> Patch following v0.7.16 — first OOXML chart render-fidelity work, legacy-shape shapeComment
> serialization, WASM options-object APIs, many rhwp-studio table/picture/cursor editing fixes,
> render-authority hardening, and a dependency bump batch. Public APIs remain backward-compatible
> (positional APIs kept) — PATCH. Browser extension 0.2.6 included.

### API
- Added options-object variants `*Ex(options_json[, image_data])` for 26 high-arity (7+) WASM
  public APIs (#1413). Existing positional APIs are kept (backward-compatible); `*Ex` performs
  the same operation via JSON options, making downstream less fragile to mid-signature changes.
  Consumer (@rhwp/core) README guidance + consumer edit API manual added (#1445).
  Convention: `mydocs/manual/wasm_api_options_convention.md`.

### Rendering (charts)
- Routed 7 of the 27 OOXML chart types whose data was already extracted (4 3D-bar, 1 3D-pie,
  2 ofPie) to 2D-approximation rendering — removes the "chart (unsupported)" placeholder
  (#1453, C1a / #1431 Track C).
- Bar charts now honor `c:grouping` (stacked/percentStacked) — 6 stacked/percent bar types (#1453).

### HWPX save contract (serializer fidelity)
- Fixed missing `hp:shapeComment` serialization on legacy shapes (ellipse/arc/polygon/curve/
  chart/ole) routed through `render_common_shape_xml` — round-trip preserved (#1451).
- Excluded false `ir-diff` differences on tab_extended reserved fields [3,4,5] (#1473).

### Rendering
- Keep v2 font authority on fallback, expand CanvasKit replay contract guards (#1429/#1447/#1469).
- TAC picture vs text vertical alignment in table cells (#1352). Reflow on un-inline picture (#1459).

### rhwp-studio
- Autosave + recovery UI for unsaved documents (#1448). Local-font detection consent (opt-in) (#1328).
- Page-border preview toggle restore (#1426). Picture insert / inline cursor fidelity (#1452).
- Table row/column insert/delete regression fix (preserve table height when adding rows/cols right
  after creation) + Hancom-style unified dialog/shortcuts (#1481).
- Table-cell drag selection + Hancom-compatible table editing (#1443), cell protection (#493).
- Block manipulation of size-locked objects (#1436), inline-picture wrap + paragraph border (#1440).
- Style apply / table caption / format copy (#1470), platform-specific menu shortcut display (#1476).

### Browser extension (0.2.6)
- Fixed viewer inline-script CSP violation (theme-init.js split) + dark icon asset recovery (#1444).
- Removed the global side effect of the Chrome `onDeterminingFilename` listener — switched to
  `onCreated`/`onChanged` observers so other extensions' `download({filename})` subfolder saves
  are no longer disrupted (#1471).

### Infra
- Track `Cargo.lock` in git — reproducible builds + stable CI cache keys (#1423, macOS FFI excluded).
- Dependency bump batch: zip 8.6.0, serde_json 1.0.150, snafu 0.9.1, subsetter 0.2.6,
  skia-safe 0.99.0, unicode-segmentation 1.13.3, wasm-bindgen-test 0.3.75, @types/chrome 0.2.0
  (#1461–#1468).

### Contributors

Contributor PRs merged in this cycle (since v0.7.16; GitHub handles, alphabetical):

- @jangster77 (Taesup Jang) — table row/column insert-delete regression (#1481), table-cell drag
  selection & editing (#1443) / cell protection (#493), TAC picture alignment / size-lock /
  inline-wrap (#1352/#1436/#1440), autosave recovery (#1448), picture/cursor fidelity (#1452/#1459),
  style/caption/shortcut (#1470/#1476)
- @johndoekim — OOXML chart C1a routing + bar stacking (#1453)
- @oksure (Hyunwoo Park) — exclude false ir-diff on tab_extended reserved fields (#1473)
- @postmelee — local-font consent (#1328), page-border toggle (#1426), Chrome download
  interceptor side-effect fix (#1471), PR review workflow docs (#1425)
- @seo-rii — keep v2 font authority (#1429), expand CanvasKit replay guards (#1447/#1469)

## [0.7.16] — 2026-06-19

> Patch following v0.7.15 — refines the HWPX save contract (serializer fidelity), fixes
> ClickHere guide-text binding in the Hancom editor, adds a drag-and-drop security gate to
> rhwp-studio, and lands many rendering/table/picture fixes plus external contributor PRs.
> Public APIs remain backward-compatible — PATCH.

### HWPX save contract (serializer fidelity)
- Preserve controls inside cell/text-box subLists, original linesegs, and table/picture/group captions (#1379/#1380/#1387/#1403).
- Emit secPr page margins and body column (colPr) definitions from the IR instead of template hardcoding (#1388/#1407).
- Preserve picture size elements (curSz/imgRect/imgDim), MEMO field parameters, shapeComment, borderFill/numbering registration axis, and table pageBreak (#1389/#1391/#1392/#1384/#1409/#1393).
- Make parser autoNum width consistent, fix newNum slot position (#1382/#1407); add an enum-token surface-format check (#1402).
- Lossless roundtrip for DocInfo, numbering paraHead, cellzoneList, useKerning/useFontSpace (#1405/#1350), and hp:tc cell field-name parsing (#1401).

### Hancom compatibility
- Fix the ClickHere guide-text (Direction) command format to match Hancom's reference output — resolves guide text not binding in the Hancom editor (#1434).

### rhwp-studio security & UX
- Exclude drag-and-drop local file loading from default behavior; require explicit opt-in via a modal confirm dialog before loading (#1439). Works in both extension and web modes.
- ClickHere form-mode/boundary editing, edit caret/focus, object aspect-ratio lock / size protection, table-cell TAC picture vertical alignment (#1419/#1428/#1430/#1436/#1352/#258).
- Dark theme support and residual UI contrast cleanup (#1420/#1422). Fix replaceAll save loss, image Shift resize, post table-create F5 handling (#1398/#1400/#1404).

### Rendering
- Native PDF export API (DocumentCore) + report-only PDF visual diff (#1359). Text IR v2 font-proof gates, exact font replay proof, glyph orientation/transform authority (#1421/#1429/#1312).
- Endnote height-model measurement SSOT / gate recalibration, official endnote shape model normalization, integral glyph (#1363/#1370/#1410/#1314/#1377); page-area-limited table-cell / rotated-cell picture placement (#1282).

### Other
- Add a 27-sample chart corpus (OOXML + legacy) verification fixture (#1431, P-1); split endnote dump / sweep verification infra (#1395).
- Preserve mixed page sizes when printing (#1383); Onsamiro picture wrap / paragraph border alignment (#1441).

### Contributors

External contributor PRs merged in this cycle (after v0.7.15; GitHub handles, alphabetical):

- @Martinel2 — useFontSpace IR field + HWP5/HWPX parser & serializer (#1350)
- @Mireutale — HWPX table-cell tab/line-break inline serialization, picture effects/shadow roundtrip (#1360/#1349)
- @jangster77 (Taesup Jang) — endnote shape model normalization, ClickHere form/edit, dark theme, table-cell picture / size protection, Onsamiro alignment (#1410/#1419/#1420/#1427/#1430/#1435/#1437/#1441), verification infra (#1395)
- @johndoekim — 27-sample chart corpus (#1431 / PR #1432)
- @msjang (Minseok Jang) — preserve mixed page sizes when printing (#1383)
- @mrshinds — TAC table host-line spacing (#1376)
- @oksure (Hyunwoo Park) — replaceAll save loss, createEmpty default section, image resize, hp:tc cell name, post-create F5, caption parse/serialize (#1398/#1399/#1400/#1401/#1404/#1406)
- @physwkim (Sang Woo Kim) — HWPX lossless roundtrip (DocInfo/cellzoneList/useKerning, etc.) (#1405)
- @planet6897 (Jaeuk Ryu) — endnote height SSOT/gate, integral glyph, endnote divergence diagnosis/closure (#1314/#1371/#1374/#1377 / PR #1390)
- @postmelee — rhwp-studio dark-mode residual UI contrast (#1422 / PR #1424)
- @seo-rii (Seohyun Lee) — renderer baseline sweep, native PDF export API, Text IR v2 font-proof gates (#1312/#1359/#1421/#1429)

## [0.7.15] — 2026-06-06

> Security patch following v0.7.14 — hardens browser-extension service-worker fetch paths,
> refines equation TAC flow/caret movement, and continues HWPX save-contract stabilization.
> Public APIs remain backward-compatible — PATCH.

### Security
- Hardened Chrome/Firefox extension document-fetch paths in the service worker (#1307).
  - Added message sender validation to separate extension viewer and content-script callers.
  - Blocked localhost, loopback, link-local, private-network, and internal-host URLs.
  - Revalidates the final URL after redirects with the same policy.
  - Uses `credentials: "omit"` for extension-side fetches.
  - Keeps automatically extracted thumbnail data out of the page DOM.
- Prepared Chrome/Edge/Firefox extension `0.2.4`: no new permissions and no new external network endpoints.

### Equation and Endnote Flow
- Improved wrapping and paragraph-indent handling for equation TAC-only lines, and fixed endnote-area caret navigation regressions (#1310).
- Reduced duplicate stops/skips when moving the caret across forced line breaks and paragraph boundaries around TAC equations (#1308/#1310).
- Follow-up fixes for endnote equation scripts, continuation spacing, and superscript alignment (#1301/#1303/#1306).

### HWPX Save Contract
- Fixed hard-coded flip/rotation and missing `isEmbeded` output in HWPX picture serialization (#1309).
- Preserved HWPX diagonal cell-border `hh:slash` / `hh:backSlash` type values (#1311).
- Preserved zero-length HWPX field ordering (#1299).

### rhwp-studio and Docs
- Separated paragraph left-margin and hanging-indent dialog bindings.
- Improved visual-sweep contributor guidance, including rsvg/font setup (#1292).
- Expanded CLI analysis/debugging command guides.

### Contributors
Thanks to Dangel for the security report and validation help, and to all external contributors and
Dependabot for this patch cycle.

## [0.7.14] — 2026-06-05

> Patch cycle following v0.7.13 (May 26–Jun 5) — focused on endnote (explanation) flow/spacing
> alignment, equation rendering/layout refinements, in-cell picture editing (insert/copy/hit-test)
> Hancom parity, HWPX save-contract extensions, and multiple external contributor PRs. Public API
> stays backward-compatible — PATCH.

### Endnote flow & spacing
- Aligned compact-endnote question-title gaps (7mm between-notes), multi-line paragraph leading,
  consecutive inline-equation multi-row merge, and below-separator margins to Hancom
  (#1240, #1241, #1247, #1255, #1259, #1262, tasks #1245/#1248/#1256/#1257/#1258)
- Corrected end-of-column line position and overflow in multi-column (EACH_COLUMN) endnote flow

### Equation rendering
- Script token handling: root/sqrt & relational glued-split, rm+bar(overline) leak, prime/cdots gluing (#1208)
- Trailing scripts bound to LEFT-RIGHT delimiter groups (`|x|^3`) (#1226)
- Big-operator (Σ/∏/∫) operand spacing; resolved Hangul compression/overlap on equation lines (#1235, #1223)
- Restored HWPX endnote/footnote prefixChar marker glyph ('문') (#1202)

### In-cell picture editing — Hancom parity
- Table + picture insert/toggle/visual/click parity (#1177), in-cell shape object-properties dialog (#1150)
- Nested-cell picture copy (Ctrl+C) + floating-object paste cascade (#1228)
- Rectangle-textbox picture click hit-test/properties/insert (#1254), nested-cell paste path preservation (#1207)
- HWP5 wrap=Square host cursor advance (answer↔question overlap), equation-only cell z-table row compression (#1220, #1225)

### Layout & rendering
- HWPX curve `<hp:seg>` outline rendering (#1203), textFlow roundtrip preservation (#1213)
- BehindText/InFrontOfText z-order composition, paper-relative BehindText z-order, master-page textbox numbering (#1163, #1252)
- Fixed 90°/270° rotated image bbox double-rotation (#1102), RawSvg(OLE/chart) first-load blank render (#1182)
- Font fidelity: Hancom Dotum fallback → Noto Sans KR ExtraLight (#1234)
- Hancom-style grid view & page borders, ghost-image fix (#1137, #1164)

### HWPX save contract
- Bookmark/Field dispatcher wiring, OLE chart, rotated picture, facing-page margin alternation, masterpage idRef (#1289, #1242)
- Globally-unique body/table-cell paragraph ids (#1222), external image reference/bytes injection contracts (#1142/#1143)

### rhwp-studio
- Reduced input-edit re-render cost (narrow invalidation) (#1212), shared modal-dialog drag
- mac window resize centering, find/goto dialog Enter handling, hit-test caret snapping (#1193, #1281, #1291)

### Infra & docs
- Dependabot coupled-dependency grouping, vite/puppeteer-core dev-dep bumps (#1214, #1216)
- macOS headless Skia font-lookup hang prevention (task #823), Rust test warning cleanup (#1180)
- Fixed ClickHere field-value file corruption (#1076)

### Contributors
@planet6897, @postmelee, @jangster77, @johndoekim, @Martinel2, @Mireutale, @chkwon, @oksure,
@seo-rii, @xogh3198, @twoLoop-40, @lidge-jun, @humdrum00001010, @HaimLee-4869, @wonbbnote
and Dependabot. Thank you.

## [0.7.13] — 2026-05-26

> Patch cycle following v0.7.12 (May 18–26) — focused on HWPX rendering/save compatibility, exam/public-agency document regressions, and multiple external contributor PR cherry-picks.

### Key Changes

- **HWPX → HWP save compatibility**
  - Added/adjusted table and cell contracts: table-axis behavior, cell LIST_HEADER materialization, gradient `BORDER_FILL`, cell inner margins, and cell background image fill mode.
  - Added memo control serialization, TOC field marker/page text output, page-number hide/restart controls, and related paragraph-control save paths.
  - Resolved multiple Hancom corruption/interrupted-render cases across `hwpx-h-01/02/03`, `mel-001`, `aift`, `exam_kor`, and `exam_social` fixtures.
- **HWPX rendering parity**
  - Implemented/improved master pages (even/odd/last), headers/footers, paragraph numbering, textbox positioning/gradient/corner radius, paragraph borders, and exam passage boxes.
  - Improved SVG and web-canvas visual parity for Hancom-converted fixtures such as `exam_kor.hwpx`, `exam_social.hwpx`, and `hwp3-sample16-hwp5.hwpx`.
- **Pagination and layout fixes**
  - Fixed HWPX `treat_as_char` table LINE_SEG lh over-inflation, nested table page splitting, picture pushdown/vpos double counting, multi-column endnote vpos, and bottom-overflow measurement consistency.
  - Added analysis infrastructure for HWP3/HWP5-converted sample16 page breaks and paragraph spacing.
- **rhwp-studio / extension UX**
  - Improved TAC shape cursor movement and repeated-space navigation behavior.
  - Chrome extension now guides users when local `file://` access is disabled and suppresses duplicate local downloads for HWP/HWPX files (#1131/#1132).
- **Infrastructure and PR intake**
  - Added CI runner disk-space mitigation (#1109).
  - Reviewed/cherry-picked external PRs including #1077/#1078/#1080/#1081/#1117/#1120/#1125/#1132.
  - Advanced CanvasKit glyph payload gating and COLRv1 glyph gradient replay.

### Remaining

- GitHub Actions outage may delay remote CI runs at v0.7.13 preparation time; local build/test/WASM validation is used as a fallback.
- The `exam_social` HWPX → HWP page-3 odd-header textbox height issue remains split into a follow-up issue.

## [0.7.12] — 2026-05-18

> Patch cycle following v0.7.11 (May 12–18) — 19 external contributor PRs merged + @jangster77 PR series of 7 (#956–#968). 416 files / +64383 / -3323.

### Key Changes

- **Original Issue #952 (1 umbrella → 5 separated defects) completed** — @jangster77 diagnostic methodology (partial fix + clear separation):
  - Issue 1 (#956): force paper-based page border outline — fixes `#920` bit-interpretation regression (verified against 5+ samples in Hancom viewer)
  - Issue 2 (#958, #957): sample16 page 18 empty caption phantom advance fix
  - Issue 3 (#961, #959): exam page 1 Q9 — horz_rel_to=Column picture out-of-column emit advance skip
  - Issue 4 (#963, #960): exam page 2 cases formula off-by-one — include end-position TAC in last run of has_line_break line
  - Issue 5 (#964, #962): exam page 2 example textbox inline equation duplicate emit block
- **WMF SetTextAlign vertical bits fix** (#966, #965): `mode & VTA_TOP(=0)` always-true bug → WMF [MS-WMF] 2.1.2.18 spec compliance (ported root cause ~60 lines from large PR #918 Stage 33-A)
- **HWP3 sample18 page count +2 inflate fix** (#968, #967): block standalone page for empty paragraph + [page break] + overflow case (v2 refinement — resolves aift.hwp snapshot regression)
- **Release build LTO + codegen-units=1 + strip** (#818, #790): rhwp CLI -28% (14→10 MB) / WASM -6.5% (4.6→4.3 MB)
- **rhwp-studio new features** (May 12–18): F5 block selection + F3 expand (#811) + menu hotkey infra (#810) + start with new page number (#809) + searchAllText API + rhwpDev.goto (#814) + Task #571 document compare/history split PR 1/3 (#799)

## [0.7.11] — 2026-05-11

> Patch cycle following v0.7.10 (May 10–11) — 30+ external contributor PRs merged. (CHANGELOG_EN.md retroactive supplement — omitted at v0.7.11 release)

- **Skia native raster incremental progress** (Issue #536): P8 (#761) Layer IR contract hardening + P9 (#769) text replay parity + P11 (#797) Text IR v2 compatibility contract
- **HWP3 native rendering** (#753): hwp3-sample10.hwp Oracle 763-page 8-stage fix + Git LFS pdf-large/ isolation
- **rhwp-studio interactions** (#781/#786–#818): scrollbar drag + chord key Ctrl+N→Ctrl+M + Korean IME chord e.code detection + Alt/Option+Arrow word navigation (#794) + table cell drag context (#795)

## [0.7.10] — 2026-05-06

> Post-v0.7.9 patch cycle — Absorbed 7 external contributors (13 PR cherry-picks) + introduced AI pipeline / VLM integration + CLI binary release pipeline (Issues #608/#612).

### New Features

- **CLI binary releases** (Issue #608/#612, by [@almet](https://github.com/almet)'s request)
  - 4-platform GitHub Release assets attached (Linux x86_64 / macOS x86_64+aarch64 / Windows x86_64)
  - SHA-256 checksums included
  - New `.github/workflows/release-binary.yml`
- **PNG raster backend** (PR #599, [@seo-rii](https://github.com/seo-rii)) — render P4 stage
  - Native Skia-based `PageLayerTree` → PNG export
  - `native-skia` feature gate (zero impact on default build, opt-in)
  - `DocumentCore::render_page_png_native(page)` API
  - **AI pipeline + VLM (Vision-Language Model) integration introduced** (maintainer follow-up fixes)
    - `--vlm-target claude` (1568 longest edge / 1.15 MP, Claude Vision compliant)
    - `--scale <factor>` / `--max-dimension <px>` (auto scale calculation)
    - `export-png` CLI command + manual (Korean + English dual)
    - Korean font fallback chain + per-character fallback (whitespace tofu fix) + `--font-path` dynamic font loading

### External PR cherry-picks (13 PRs / 7 contributors)

#### [@planet6897](https://github.com/planet6897) / Jaeook Ryu — collaborative flow

- PR #587 — HWP 5.0 spec 0x18/0x1E swap (hyphen ↔ non-breaking space)
- PR #589 (Task #511 v2 + #554) — HWP3 Square wrap supplementary fix + conversion identification heuristic
- PR #561 (Task #548) — Cell inline TAC Shape margin + indent
- PR #564 (Task #521) — TAC table outer_margin_bottom missing
- PR #570 (Task #568) — Inline table + equation paragraph right-shift
- PR #575 (Task #573) — Choice cell fraction paragraph routing
- PR #580 (Task #577) — Cell-internal standalone TopAndBottom image 1-line offset
- PR #584 (Task #574) — HY견명조 heavy display misclassification (TDD)
- PR #592 (Task #588) — exam_eng.hwp p7 arrow missing (PUA U+F003B mapping)
- PR #593 (Task #590) — Square wrap table horz_rel_to=Column attribute
- PR #567 (Task #565) — Inline equation render-missing

#### [@oksure](https://github.com/oksure) (Hyunwoo Park)

- PR #600 (closes #513) — Supplementary PUA-A SVG output fix

#### [@seo-rii](https://github.com/seo-rii)

- PR #599 (refs #536) — native Skia PNG raster backend

### Maintainer Fixes

- 5 Skia font area fixes (PR #599 follow-up, `876d820`): Korean font fallback chain / `--font-path` dynamic loading / per-character fallback / VLM options / `export-png` CLI

### Infrastructure

- CI build stability (`[[example]] required-features`)
- Wide pagination regression sweep tooling (164 fixtures / 1,614 pages auto-verification)

### Follow-up Issues

- [#613](https://github.com/edwardkim/rhwp/issues/613) — VLM preset expansion
- [#614](https://github.com/edwardkim/rhwp/issues/614) — DPI metadata option
- [#615](https://github.com/edwardkim/rhwp/issues/615) — `pua_oldhangul.rs` Hancom alignment
- [#598](https://github.com/edwardkim/rhwp/issues/598) — rhwp-studio footnote deletion (open)

### Remaining PRs (deferred to v0.7.11)

- PR #601, #602 (@oksure) / PR #607 (@dicebattle) / PR #609 (@jangster77) / PR #611 (@kihyunnn)

---

## [0.7.9] — 2026-05-01

> Post-v0.7.8 cycle — Task #501 (Hancom defensive logic for cell.padding) + cherry-pick of PR #428/#494/#478/#498 + 4 external contributors

### Regression Fixes (Maintainer)

- **Task #501 — mel-001.hwp page 2 table cell height regression** (closes #501)
  - Root cause: HWP cell IR with `cell.padding.top + bottom > cell.height` (mel-001 cell[21] r=2 c=2 "현 원": pad=(141,141,1700,1700), cell.h=1280 HU). HWPX `hasMargin="0"` confirmed.
  - Regression origin: Task #347's `prefer_cell_axis` guard applied cell-priority even for abnormal padding → row_heights inflated → TAC table proportional shrink (scale 0.45) → all rows reduced to 12-20px + cell entry failure.
  - Fix: Added **Hancom-defensive-logic mimic** guard at the end of `resolve_cell_padding` — if pad_top + pad_bottom > cell.height, scale them down proportionally to half of cell.height. Added the same guard in `measure_table_impl` step 1-b as a safety net.
  - Maintainer insight: *"What if Hancom handles this case with its own defensive logic?"* — Preserved Task #347 guard (KTX TOC R=1417 HU compatibility) + added Hancom-behavior-mimic guard
  - Wrote troubleshooting and wiki page ([HWP Cell Padding Defensive Logic](https://github.com/edwardkim/rhwp/wiki/HWP-%EC%85%80-Padding-%EB%B0%A9%EC%96%B4-%EB%A1%9C%EC%A7%81))

### External PR Cherry-picks (3 PRs / 17 commits)

- **PR #428 — Picture serialization within group** (by [@oksure](https://github.com/oksure))
  - Implemented the empty-TODO `ShapeObject::Picture` branch in `serialize_group_child` — fixes data loss for pictures inside groups when saving HWP
  - Added SHAPE_COMPONENT + SHAPE_COMPONENT_PICTURE records (matching Chart/OLE child pattern) + magic constant cleanup (`tags::SHAPE_PICTURE_ID`)

- **PR #494 — Paragraph::utf16_pos_to_char_idx public API** (#484, by [@DanMeon](https://github.com/DanMeon))
  - External binding work in the same vein as PR #405 — encapsulated `helpers::utf16_pos_to_char_idx` (pub(crate)) algorithm as `Paragraph::utf16_pos_to_char_idx(&self, utf16_pos: u32) -> usize` (pub)
  - 6 unit tests added, semver MINOR-compatible scope (+1 method, no algorithm change)

- **PR #478 — Layout/equation fixes bundled** (by [@planet6897](https://github.com/planet6897))
  - From the 9-Task / 97-commit accumulated PR, cherry-picked **7 Tasks / 10 commits** that don't directly affect page layout (5-stage merge)
  - **#488** (equation tokenizer font-style keyword prefix split + svg/canvas renderer italic honor) — 14 unit tests added
  - **#490** (alignment for empty-text + TAC equation cells) — exam_science p1 cells 7/11 with 28/36 equation now centered
  - **#483** (footnote multi-paragraph line_spacing + trailing line_spacing follow-up)
  - **#489** (Picture+Square wrap host paragraph text LINE_SEG cs/sw applied)
  - **#495** (cell paragraph inline-Shape branch guard — partial fix; remainder split into [issue #502](https://github.com/edwardkim/rhwp/issues/502))
  - **#480** (wrap=Square table paragraph margin reflected in x coordinate)
  - **#476** (PartialParagraph inline Shape page routing, +881/-4)
  - Not absorbed: #479 (paragraph trailing line_spacing / HWP vpos) — requires Hancom 2020 reference visual verification, split into [issue #503](https://github.com/edwardkim/rhwp/issues/503)

### Regression Verification Infrastructure (External)

- **PR #498 — Canvas visual diff pipeline** (relates #364, by [@seo-rii](https://github.com/seo-rii))
  - Follow-up P3 verification layer for PR #456 (P2 PageLayerTree replay transition) — added rhwp-studio E2E with **automated pixel-diff comparison** of legacy Canvas vs PageLayerTree replay Canvas + GitHub Actions Render Diff workflow
  - 7 commits split (test + diagnostics + docs + CI runner + 3 security hardening)
  - Scope: JS E2E + CI workflow + docs + Vite config (zero Rust changes)
  - Confirmed 0 diff on the 3 default fixtures (KTX / biz_plan / tac-case-001)

### Split Follow-up Issues

- [#502](https://github.com/edwardkim/rhwp/issues/502) — Inline TextBox TextRun handling within a paragraph (Task #495 remainder)
- [#503](https://github.com/edwardkim/rhwp/issues/503) — Task #479 essential fix absorption (requires Hancom 2020 reference visual verification)

### Wiki Updates

- [HWP Cell Padding Defensive Logic](https://github.com/edwardkim/rhwp/wiki/HWP-%EC%85%80-Padding-%EB%B0%A9%EC%96%B4-%EB%A1%9C%EC%A7%81) (new)
- [Hancom PDF Environment Dependency](https://github.com/edwardkim/rhwp/wiki/%ED%95%9C%EC%BB%B4-PDF-%ED%99%98%EA%B2%BD-%EC%9D%98%EC%A1%B4%EC%84%B1) — added Case IV (21_언어_기출: Hancom 2020 = rhwp output)

### Verification

- cargo test --lib 1086 → **1102 passed**
- cargo test --test svg_snapshot 6/6, issue_418 1/1, issue_501 PASS (new integration test)
- cargo clippy --lib -- -D warnings 0 warnings
- WASM 4,206,487 bytes (after Task #501) → 4,202,430 bytes (after PR #478 5th merge) → 4,211,280 bytes (after #480)

## [0.7.8] — 2026-04-29

> Post-v0.7.7 cycle — multiple external contributors, maintainer regression fixes, and wiki/README organization

### External PR cherry-picks (15 items)

Library core fixes (typesetting / pagination / serialization):

- **PR #391 Multi-column section accumulation formula regression fix** (#391, by [@planet6897](https://github.com/planet6897))
  - `src/renderer/typeset.rs` accumulation formula branched by `col_count`: single-column → `total_height`, multi-column → `height_for_fit` (suppresses trailing_ls inflation)
  - exam_eng (2-column): 11 → **8 pages**, single 1-item column issues (p3/p5/p7) all resolved

- **PR #396 Equation rendering improvements** (#174, #175, by [@oksure](https://github.com/oksure))
  - Set inline equation height based on `eq.common.height` (HWP authoritative value) + apply X/Y scaling simultaneously
  - Disable italic styling and width compensation for CJK characters in equations — fixes CASES Korean line overlap
  - Maintainer follow-up fixes (3 items): Canvas fraction line y / Equation scale / Limit fi=fs

- **PR #395 Image brightness/contrast effects in SVG output** (#150, by [@oksure](https://github.com/oksure))

- **PR #397 Equation ATOP parsing and rendering fix** (by [@cskwork](https://github.com/cskwork))
  - **First external contributor to this repository** — `EqNode::Atop` AST parsing + above/below layout without fraction line (separates HWP's ATOP / OVER semantics)

- **PR #400 HWPX equation serialization preservation** (#286, by [@cskwork](https://github.com/cskwork))
  - Fix `render_paragraph_parts` ignoring controls + parser XML entity restoration
  - Verified: Hancom Hangul 2020 normal viewing + PDF match (added Hancom-origin hwp roundtrip regression commit `ecd7d9a`)

- **PR #401 v2 Table page split rowspan>1 cell unit policy** (#398, by [@planet6897](https://github.com/planet6897))
  - `BLOCK_UNIT_MAX_ROWS=3` threshold — protect small blocks (≤3 rows) only, allow row-unit split for large rowspans (≥4 rows) — Hancom-compatible
  - synam-001.hwp page 5 regression fixed (35→37→**35** pages)

- **PR #406 Inline TAC image pagination fix in same paragraph** (#402, by [@planet6897](https://github.com/planet6897))
  - Fixed second inline image in the same paragraph being drawn at the same y-coordinate as the first, causing overlap/overflow
  - 27→30 pages (split normalized)

- **PR #408 heading-orphan vpos-based correction** (#404, by [@planet6897](https://github.com/planet6897))
  - vpos-based 5-condition AND trigger (current fits + vpos overflow + next substantial + next doesn't fit + single column non-wrap) — only 1 of 41 vpos overflow cases is a true orphan
  - Page 9 pi=83 heading → pushed to page 10, placed together with subsequent table

- **PR #410 TopAndBottom Picture vert=Para chart fix + atomic TAC top-fit** (#409, by [@planet6897](https://github.com/planet6897))
  - v1: Extend `prev_has_overlay_shape` guard (Picture + TopAndBottom + vert=Para)
  - v2: `typeset_section` controls loop chart height accumulation
  - v3: `typeset_paragraph` atomic TAC top-fit semantics (60px tolerance)

- **PR #415 Task #352 dash sequence Justify width inflation fix** (#352, by [@planet6897](https://github.com/planet6897))
  - dash leader elastic Justify distribution (PDF-mimicking), exam_eng Q32 dash advance 12.11 → 7.06 px

- **PR #424 Multi-column right column single-line paragraph line spacing fix (vpos correction anchor)** (#412, by [@planet6897](https://github.com/planet6897))
  - layout.rs vpos correction formula fix — introduce `col_anchor_y` (preserves anchor right after body_wide_reserved push), prefer `curr_first_vpos`, separate page_path/lazy_path
  - exam_eng p1 right column item 7 ①~⑤ 15.33→**22.55px uniform**, left column item 1 catch-up 28.56→21.89

- **PR #427 SvgRenderer defs deduplication unified to HashSet** (#423, by [@oksure](https://github.com/oksure))
  - `arrow_marker_ids: HashSet<String>` → unified `defs_ids: HashSet<String>`, O(n)→O(1)

- **PR #434 Image auto-crop (FitToSize+crop) formula correction + paragraph border inner padding** (#430, by [@planet6897](https://github.com/planet6897))
  - svg.rs / web_canvas.rs crop scale formula correction (`cr/img_w` → `original_size_hu/img_size_px`) + helper `compute_image_crop_src` extraction (single source of truth for SVG/Canvas)
  - Separate fix: paragraph border inner padding (text sticking to border)

API additions / tooling:

- **PR #405 `Paragraph::control_text_positions` added** (#390, by [@DanMeon](https://github.com/DanMeon))
  - API refactor for external binding exposure

- **PR #411 `editor.exportHwp()` API added** (by [@ggoban](https://github.com/ggoban))
  - First-time contributor — exposed exportHwp() on iframe wrapper `@rhwp/editor`

- **PR #413 rhwp-studio PWA support** (#383, by [@dyjung150605](https://github.com/dyjung150605))
  - First-time contributor — vite-plugin-pwa, manifest scope `/rhwp/`, icon 192/512/maskable, registerType=autoUpdate, WASM precache

- **PR #419 PageLayerTree generation API introduced** (#364, by [@seo-rii](https://github.com/seo-rii))
  - New `paint` module (2,376 lines, builder/json/layer_tree/paint_op) — PageRenderTree → PageLayerTree conversion
  - opt-in transition adapter (`svg_layer.rs`, `RHWP_RENDER_PATH=layer-svg`)
  - Existing 5 renderer files unchanged (0 lines), 309 pages SVG byte-identical across the board (fidelity analysis report)

### Maintainer work (3 items)

- **Task #394 Disable cell-entry transparent border auto-on logic** (#394)
  - input-handler.ts 5 areas commented out — Hancom output alignment

- **Task #416 `find_bin_data` guard defect fix** (#416)
  - Removed `c.id == bin_data_id` guard — `c.id` is storage_id, bin_data_id is index. sparse id range branching (preserves HWPX chart 60000+N). 7 unit tests added

- **Task #418 `hwpspec.hwp` p20 empty paragraph + TAC Picture double emit fix** (#418)
  - Task #376 fix commit was not merged into devel (closed but only existed on temporary branch) → same defect recurred
  - Added paragraph_layout set_inline_shape_position + already_registered guard in layout.rs::layout_shape_item
  - New memory (verify devel-merged commit on close) + new troubleshooting document

### Maintenance / documentation

- **Wiki page [Hancom PDF Environment Dependency](https://github.com/edwardkim/rhwp/wiki/한컴-PDF-환경-의존성) enhanced**
  - Added "Discovery II (PR #434 / Issue #430)" section — Hancom 2010 ↔ 2020 ↔ Hancom Docs render the same hwp differently. Re-confirms the limit of the single-Hancom-reference assumption.
  - rhwp's current output may better match the test sheet author's intent (preserves original JPEG "(A type)" residue)

- **README.md / README_EN.md enhanced**
  - Added "Hancom PDFs are not authoritative ground truth" item to Contributing section
  - New "Wiki Resources" subsection (9 wiki page links)

- **samples reference materials added** — shared with all contributors and fork users
  - `samples/2010-exam_kor.pdf` (Hancom 2010, 4.57 MB)
  - `samples/2020-exam_kor.pdf` (Hancom 2020, 4.57 MB)
  - `samples/hancomdocs-exam_kor.pdf` (Hancom Docs, 6.05 MB)
  - `samples/복학원서.pdf` (Issue #421 Hancom reference)
  - `samples/synam-001.hwp` (PR #401 regression verification)
  - `samples/atop-equation-01.hwp` (PR #397 visual judgment)

### Verification

- `cargo test --lib`: **1066 passed** (1008 → +58, 0 regressions)
- `cargo test --test svg_snapshot`: 6/6 passed
- `cargo test --test issue_418`: 1/1 passed (Task #418 regression preserved)
- `cargo clippy --lib -- -D warnings`: 0 warnings
- WASM build: 4,182,395 bytes (delta +47 KB)
- Wide byte-level comparison: 10 samples / 309 pages SVG regression verification (per-PR verification gate)
- Maintainer SVG + Canvas dual-path visual judgment (PR #401 v2 / #406 / #408 / #410 / #415 / #424 / #434)

### Acknowledgments to External Contributors

External contributors in this cycle (alphabetical):
[@cskwork](https://github.com/cskwork), [@DanMeon](https://github.com/DanMeon), [@dyjung150605](https://github.com/dyjung150605), [@ggoban](https://github.com/ggoban), [@oksure](https://github.com/oksure), [@planet6897](https://github.com/planet6897), [@seo-rii](https://github.com/seo-rii)

In particular, [@cskwork](https://github.com/cskwork) became the **first external contributor to this repository** with two merged PRs (#397, #400), and [@planet6897](https://github.com/planet6897) diagnosed and fixed the majority (8 PRs) of external PRs in this cycle.

## [0.7.7] — 2026-04-27

> v0.7.6 regression fix cycle (restoring missing semantics after TypesetEngine default switch)

### Fixes — TypesetEngine regression corrections

- **Pagination fit accumulation drift fix** (#359)
  - Separate fit determination from accumulation in typeset: fit uses `height_for_fit` (excluding trailing_ls), accumulation uses `total_height` (full)
  - Added single-item page block guard — skip empty paragraphs / disable safety margin once when next pi's vpos-reset guard is about to trigger
  - **k-water-rfp**: LAYOUT_OVERFLOW 73 → 0 (drift 311px corrected)
  - **kps-ai**: 60 → 4

- **TypesetEngine page_num + PartialTable fit safety margin** (#361)
  - Aligned NewNumber application conditions in `finalize_pages` with Paginator semantics (`prev_page_last_para` tracking, applied once per page)
  - Disabled fit safety margin (10px) right after PartialTable — PartialTable's cur_h is row-accurate
  - **k-water-rfp**: 28 → 27 pages (page_num updated correctly)
  - **kps-ai**: page_num 1, 2, 1, 1, 2~8 normal (NewNumber control handling)

- **kps-ai PartialTable + Square wrap handling** (#362, 8 cumulative items)
  - **wrap-around mechanism (Square wrap) port** ★ — Ported wrap zone matching + activation semantics from Paginator engine.rs:288-372 to TypesetEngine. Paragraphs beside outer table absorbed without consuming height
  - Outer cell vpos guard — exclude LineSeg.vertical_pos in nested table cells (blocks p56 clip)
  - Allow nested PartialTable split — display split instead of atomic deferral for nested tables larger than one page (blocks p67 empty page)
  - Accurate PartialTable remaining height calculation — new `calc_visible_content_height_from_ranges_with_offset`
  - Strengthened nested table cell capping (cap by outer row height)
  - Added hide_empty_line to TypesetEngine (max 2 empty lines at page start with height=0)
  - vpos-reset guard ignored within wrap zone (blocks misfire)
  - Strengthened empty paragraph skip guard — paragraphs with table/shape controls are not skipped (blocks pi=778 table omission)
  - **kps-ai**: 88 → 79 pages (matches Paginator's 78, LAYOUT_OVERFLOW 60→5)

### Security

- **rhwp-firefox/build.mjs CodeQL Alert #17 resolved** (#354)
  - `execSync` shell usage → `execFileSync` (`shell: false`)

### Verification

- `cargo test --lib`: 1008 passed, 0 failed
- `cargo test --test svg_snapshot`: 6/6
- `cargo test --test issue_301`: 1/1
- WASM build passed
- Maintainer visual judgment passed (kps-ai p56, p67-70, p72-73, k-water-rfp full)

## [0.7.6] — 2026-04-26

> Multiple external contributors + typesetting precision cycle

### Added
- **`replaceOne(query, newText, caseSensitive)` WASM API** (#268)
  — Analyzed and implemented by [@oksure](https://github.com/oksure) (new contributor)
  - Resolved crash from position-based vs query-based call mismatch in `replaceText`
  - 100% backward compatibility preserved with new API
  - 5 unit tests (including Korean multi-byte boundaries)

- **SVG/HTML draw_image base64 embedding** (#335)
  — Analyzed and implemented by [@oksure](https://github.com/oksure)
  - Existing placeholders (`<rect>`/`<div>`) → actual image base64 data URI embedding
  - Backend alignment with `render_picture` / `web_canvas`

### Fixed
- **TOC reader dots + page number right-tab alignment** (#279)
  — Analyzed and implemented by [@seanshin](https://github.com/seanshin)
  - Express `fill_type=3` dotted reader as round-cap dots (Hancom-equivalent)
  - Excluded `find_next_tab_stop` RIGHT-tab clamping — corrects page number alignment in indented paragraphs
  - Maintainer enhancements: cell-padding-aware leader semantics, leader length differentiation by page number width, blank-only run carry-over

- **form-002 inner table page split defect** (#324)
  — Analyzed and implemented by [@planet6897](https://github.com/planet6897)
  - `compute_cell_line_ranges` rewritten from residual-tracking to cumulative-position (`cum`)-based
  - `layout_partial_table` `content_y_accum` update + unified split-start row calculation
  - Author self v1 → v2 → v3 enhancements

- **typeset path PageHide / Shape / duplicate emit defects** (#340)
  — Analyzed and implemented by [@planet6897](https://github.com/planet6897)
  - Unified diagnosis of three defects as common cause (typeset.rs omissions)
  - Alignment with `engine.rs` (PageHide collection + `pre_text_exists` guard + Shape inline registration)

- **Firefox AMO warning resolved (rhwp-firefox 0.2.1 → 0.2.2)** (#338)
  — Analyzed and implemented by [@postmelee](https://github.com/postmelee)
  - manifest `strict_min_version` raised to 142 (`data_collection_permissions` compatibility)
  - sanitized unsafe `innerHTML` / `Function` / `document.write` in `viewer-*.js`
  - rhwp-studio 28-file DOM/SVG API replacement + Reviewer Notes (KO/EN)

- **Task #321~#332 cumulative cleanup + vpos/cell padding regression resolution** (#342)
  — Analyzed and implemented by [@planet6897](https://github.com/planet6897)
  - Bidirectional vpos correction guard + cell padding aim explicit-value precedence policy
  - typeset/layout drift alignment + KTX TOC results (#279) restored per maintainer review feedback

### Other
- **New contributor welcome** — README.md / README_EN.md Contributing section explicitly states PR base=devel (follow-up improvement after #330 close)

## [0.6.0] — 2026-04-04

> Typesetting quality improvements + non-functional foundation — "Breaking the egg, into the world"

### Added
- **GitHub Actions CI**: Build + test + Clippy strict mode (#46, #47)
- **GitHub Pages demo**: https://edwardkim.github.io/rhwp/ (#48)
- **GitHub Sponsors**: Sponsor button activated
- **Image cropping**: SVG viewBox / Canvas drawImage image crop rendering (#43)
- **Image border**: Picture border_attr parsing + border rendering (#43)
- **Header/footer Pictures**: non-TAC image absolute positioning, TAC image inline placement (#42)
- **Logo asset management**: assets/logo/ source-managed, favicon generation
- **Non-functional work plan**: 13 items in 6 areas, 3-stage milestones (#45)

### Fixed
- **Same-paragraph TAC + block table**: Prevented intermediate TAC vpos gap negative regression (#41)
- **Split-table cell vertical alignment**: Forced Top in split rows, reflected nested table height (#44)
- **TAC table trailing ls**: Boundary condition cyclic error resolved (#40)
- **Currency symbol rendering**: ₩€£¥ Canvas Malgun Gothic fallback, SVG font chain (#39)
- **Half-/full-width precision**: Removed Bold-fallback compensation, half-width smart quotes / middle dot (#38)
- **Font-name JSON escaping**: Fixed font-name load failure with backslash (#37)
- **Header table cell image**: Fixed bin_data_content propagation path (#36)
- **Clippy warnings removed**: 6 issues including unnecessary_unwrap, identity_op (#47)

## [0.5.0] — 2026-03-29

> Skeleton complete — reverse-engineered HWP parser/renderer

### Core features
- **HWP 5.0 / HWPX parser**: OLE2 binary + Open XML format support
- **Rendering engine**: paragraphs, tables, equations, images, charts, header/footer/master pages/footnotes
- **Pagination**: multi-column split, table row split, shape_reserved handling
- **SVG export**: CLI (`rhwp export-svg`)
- **Canvas rendering**: WASM/Web-based
- **Web editor**: rhwp-studio (text editing, formatting, table creation)
- **hwpctl-compatible API**: 30 Actions, Field API (Hancom Web Hangul-compatible)
- **VS Code extension**: HWP/HWPX viewer (v0.5.0~v0.5.4)
- **755+ tests**

### Typesetting engine
- Line spacing (fixed/percent/by-character), paragraph margins, tab stops
- Table cell merging, border styles, cell formula calculation
- Multi-column layout, paragraph numbering / bullets
- Vertical text, object placement (block/in-line/in-front-of-text/behind-text)
- Inline TAC tables / pictures / equations rendering

### Equation engine
- Fractions (OVER), roots (SQRT/ROOT), subscripts/superscripts
- Matrices: MATRIX, PMATRIX, BMATRIX, DMATRIX
- Cases (CASES), alignment (EQALIGN), integral/sum/product operators
- 15 text decorations, Greek letters, 100+ math symbols
