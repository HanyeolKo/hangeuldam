# rhwp — HWP 문서 뷰어 & 에디터 (Firefox 확장)

브라우저에서 HWP/HWPX 파일을 바로 열고 편집할 수 있는 확장 프로그램입니다.

## v0.9.0 변경사항

- 중첩 표·쪽을 넘는 표·글상자·셀 안 그림과 머리말/꼬리말 배치를 개선했습니다.
- 그림 이동·셀 그림 삽입·Undo/Redo, 연속 형광펜, 문단 서식과 저장 재열기 보존을 보강했습니다.
- 수식·글꼴 fallback과 큰 표/JPEG 처리 경로를 개선했습니다.
- 공통 엔진의 PDF 가져오기·암호 인증·쪽별 진행률을 제공합니다.
  CLI·Rust·Studio의 사용법과 지원 경계는 [PDF 시작 안내](../mydocs/manual/pdf_developer_onboarding.md)를 참고하세요.
  확장의 웹 링크·다운로드 자동 감지 대상은 HWP/HWPX이며 모든 웹 PDF를 가로채지는 않습니다.
- v0.8.7 대비 manifest 권한·CSP는 동일합니다. 스토어의 0.9.0 게시 완료를 뜻하지 않습니다.

전체 변경과 기여자는 [0.9.0 릴리즈 노트](../mydocs/release/release_notes_v0.9.0.md)에 정리했습니다.

## 특징

- **설치 없이 열기** — 확장 설치 한 번이면 HWP/HWPX 파일을 브라우저에서 바로 열람
- **편집 지원** — 텍스트 입력/수정, 표 편집, 서식 변경
- **인쇄** — Ctrl+P로 인쇄, PDF 저장 가능
- **자동 감지** — 웹페이지의 HWP/HWPX 링크를 자동 감지하고 아이콘 표시
- **개인정보 보호** — 파일이 서버로 전송되지 않음, 모든 처리는 브라우저 내 WASM
- **무료** — MIT 라이선스, 개인/기업 무료
- **광고 없음**

## 설치

- [Firefox Add-ons (AMO)](https://addons.mozilla.org/firefox/addon/rhwp-free-hwp-editor/)

## 사용 방법

### HWP/HWPX 파일 열기

1. **웹 다운로드**: HWP/HWPX 파일 다운로드 시 자동으로 뷰어 탭에서 열림
2. **드래그 & 드롭**: 확장 아이콘 클릭 → 빈 뷰어 탭 → 파일 드래그
3. **우클릭 메뉴**: HWP/HWPX 링크 우클릭 → "rhwp로 열기"
4. **배지 클릭**: 웹페이지의 HWP/HWPX 링크 옆 파란색 H 배지 클릭

### 인쇄

- 파일 메뉴 → 인쇄 또는 **Ctrl+P**
- 인쇄 미리보기 창에서 [인쇄] 버튼 클릭

### 저장

- **Ctrl+S** 또는 파일 메뉴 → 저장
- HWP·HWPX 형식 저장 지원 (HWPX→HWP 변환 저장 포함, v0.8.0 엔진)

## 웹사이트 개발자

공공 웹사이트에 `data-hwp-*` 속성을 추가하면 사용자 경험이 향상됩니다.
자세한 내용은 [개발자 가이드](../rhwp-chrome/DEVELOPER_GUIDE.md)를 참조하세요.

```html
<a href="/files/공문.hwp" data-hwp="true" data-hwp-title="공문" data-hwp-pages="5">
  공문.hwp
</a>
```

## 빌드

같은 checkout의 `pkg/` WASM과 Studio 의존성을 먼저
[개발 환경 가이드](../mydocs/manual/dev_environment_guide.md)에 따라 준비합니다.

```bash
cd rhwp-firefox
npm ci
npm run build
```

빌드 결과물은 `dist/` 폴더에 생성됩니다.

### 개발 모드 설치

1. Firefox 주소창에 `about:debugging#/runtime/this-firefox` 입력
2. "임시 부가 기능 로드..." 클릭
3. `rhwp-firefox/dist/manifest.json` 선택

### Chrome 확장과의 차이

이 확장은 [rhwp-chrome](../rhwp-chrome/)을 기반으로 Firefox WebExtensions API에 맞게 포팅하였습니다.

주요 차이점:
- `manifest.json`: `service_worker` → `background.scripts` (Firefox MV3 규격)
- `background.js`: `browser.*` 네임스페이스 사용 (Firefox 네이티브 Promise API)
- `sw/download-interceptor.js`: `onDeterminingFilename` → `onCreated` (Firefox 호환)

## 다운로드·저장 E2E 테스트

저장소 루트에서 빌드된 확장을 실제 Firefox의 격리 프로필로 실행합니다. HWP 다운로드 후
뷰어 1개, 편집 후 저장·다른 이름으로 저장, 저장본의 편집 내용 보존을 확인합니다.
기존 Firefox 설치의 프로필을 사용하지 않습니다.

먼저 루트 `pkg/` WASM을 [개발 환경 가이드](../mydocs/manual/dev_environment_guide.md)에 따라
준비하고, Studio와 두 확장의 빌드·테스트 의존성을 설치합니다. Puppeteer는 Chrome 확장에
선언된 버전을 공유하므로 `rhwp-chrome` 의존성도 필요합니다.

```sh
npm ci --prefix rhwp-studio
PUPPETEER_SKIP_DOWNLOAD=true npm ci --prefix rhwp-chrome
npm ci --prefix rhwp-firefox
npm --prefix rhwp-firefox run build
FIREFOX_EXECUTABLE_PATH=/path/to/firefox npm --prefix rhwp-firefox run test:e2e:download
```

`test:e2e:download`는 준비된 dist를 검사하며 자동으로 다시 빌드하지 않습니다.
`RHWP_FIREFOX_DIST=/absolute/path/to/dist`로 검증할 패키지를 선택할 수 있습니다.
파일명 수정(#6965)까지 포함된 패키지는 `RHWP_EXPECT_BASENAME=1`을 추가하면 파일명도 검사합니다.
이 테스트는 수동 실행 진입점이며 현재 CI에 자동 연결되어 있지는 않습니다.

## 변경 이력

### v0.8.7 (2026-10-06)

- TAC 표의 줄 배치와 중첩 표·rowspan의 페이지 분할을 보정했습니다.
- 영어 UI, 하이퍼링크 편집, 찾기 결과 표시와 표 편집을 개선했습니다.
- 문서 입력과 썸네일 처리 경계를 보강하고 다운로드·저장본 자동 열기를 보정했습니다.
- 기존 확장 권한을 유지합니다. 자세한 변경사항은 [전체 변경 이력](../CHANGELOG.md)을 확인하세요.


### v0.8.6 (2026-09-02)

- 최종 파일명이 `.xlsx`인 다운로드는 임시 source URL이 `.hwp`로 끝나거나 HWP MIME을
  제공해도 viewer로 잘못 열지 않도록 최종 파일명·MIME 우선순위를 보강
- 조판·폰트·저장 정확도와 편집 기능을 보강한 rhwp core v0.8.6 WASM 번들 반영
- v0.8.4 대비 새 확장 권한, 새 외부 네트워크 endpoint 및 remote JavaScript 없음
- Firefox `data_collection_permissions.required` 값 `none` 유지

전체 프로젝트 변경 이력은 [root CHANGELOG](../CHANGELOG.md)를 참조하세요.

### v0.8.0 (2026-07-26)

> 이번 버전부터 확장 버전을 문서 엔진 버전과 통일합니다 (0.2.8 다음이 0.8.0).

**문서 엔진 대규모 업데이트 (rhwp core v0.8.0)**
- 저장 신뢰성 대공사 — 편집 내용(양식 값·책갈피·스타일·표 테두리 등)이 저장 시 유실·원복되던 문제 대량 수정
- HWPX 저장 왕복 보존 수십 건, 편집 취소(undo) 정합, 글꼴 처리 일원화(1만 건 실문서 검증 쪽수 회귀 0)
- 손상/악성 파일 파서 방어 강화, 한글 입력 반응성 개선

**확장 자체 변경**
- 설정 저장·복구와 다운로드 자동 열기 방어 강화
- 새 권한 없음, 새 외부 네트워크 endpoint 없음

### v0.2.5 ~ v0.2.8 (2026-06)

- rhwp core 0.7.16~0.7.19 번들 반영, 드래그&드롭 보안 확인 단계, CSP 준수 보강,
  브라우저 재시작 후 과거 다운로드 재열림 차단 핫픽스 연작

### v0.2.4 (2026-06-06)

**보안 강화**
- service worker의 HWP/HWPX 문서 fetch 경로 sender 검증 보강
- localhost, loopback, private network, link-local, 내부 호스트명 URL 차단
- redirect 이후 최종 URL 재검증 및 `credentials: "omit"` 적용
- 자동 thumbnail 데이터가 page DOM에 직접 노출되지 않도록 hover card 내부 처리 보강
- 새 권한 없음, 새 외부 네트워크 endpoint 없음

**번들 업데이트**
- rhwp core `0.7.15` WASM 번들 반영
- 수식 TAC 흐름, 커서 이동, HWPX 저장 계약 후속 수정 반영

### v0.2.3 (2026-05-26)

**번들 업데이트**
- rhwp core `0.7.13` WASM 번들 반영
- 로컬 `file://` HWP 열기 안내와 중복 다운로드 억제 개선
- HWPX 렌더링/저장 호환성 누적 수정 반영

### v0.2.2 (2026-04-26)

**보안·품질 개선**
- AMO 검증 워닝 해소 + 보안 강화 (외부 기여 by [@postmelee](https://github.com/postmelee) — PR [#339](https://github.com/edwardkim/rhwp/pull/339))
  - `manifest.json` 의 `strict_min_version` 을 `142.0` 으로 상향 (`data_collection_permissions` 호환)
  - 인쇄 팝업 경로의 `document.write` 를 DOM API 기반으로 변경
  - 메뉴/오버레이/대화상자 경로의 `innerHTML` 사용을 DOM API · `textContent` · `replaceChildren()` · SVG DOM 생성 방식으로 변경
  - 빌드 시 stale artifact 가 dist 에 섞이지 않도록 정리 단계 보강
- 목차 리더 도트 + 페이지번호 우측 탭 정렬 (외부 기여 by [@seanshin](https://github.com/seanshin) — PR [#282](https://github.com/edwardkim/rhwp/pull/282))
  - `fill_type=3` 점선 리더를 round cap 원형 점으로 표현 (한컴 동등)
  - 들여쓰기 문단의 페이지번호 정렬 보정

**기여자 감사**
이번 배포 주기에 기여해주신 분들: [@postmelee](https://github.com/postmelee), [@seanshin](https://github.com/seanshin)

### v0.2.1 (이전)

- AMO 등록 준비 (rhwp-firefox 첫 공개 빌드)

## 라이선스

MIT License — Copyright (c) 2026 Edward Kim

## 개인정보 처리방침

[PRIVACY.md](PRIVACY.md) 참조
