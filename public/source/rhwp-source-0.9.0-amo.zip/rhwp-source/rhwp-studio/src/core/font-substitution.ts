/**
 * 폰트 치환 모듈 — web/font_substitution.js를 TypeScript로 포팅
 *
 * webhwp의 g_SubstFonts 치환 테이블 기반.
 * HWP 문서에서 사용하는 폰트 이름을 웹에서 렌더링 가능한 폰트로 변환한다.
 *
 * 3계층 해소:
 *   1. @font-face 등록 폰트 → 그대로 사용
 *   2. g_SubstFonts 치환 체인 → 등록된 폰트까지 체인 추적
 *   3. 최종 fallback → generic serif/sans-serif
 */

import { getDetectedOSFonts, hasLoadedLocalFontFamily, REGISTERED_FONTS } from './font-loader.ts';
import { getLocalFontState, resolveLocalFont } from './local-fonts.ts';
import { TEXT_SYMBOL_FONT_FAMILIES } from './text-symbol-font.ts';

import {
  FONT_RULE_DISPLAY_CHAIN_POLICY_IDS,
  FONT_RULE_GOVERNMENT_SUCCESSORS,
  FONT_RULE_SUBSTITUTION_TABLES,
  projectedSubstituteTargets,
} from './font-rule-runtime.ts';

interface SubstitutionTarget {
  face: string;
  type: number;
  ruleId: string;
}

// 언어별 치환 해시맵 (생성 projection을 초기화 시 1회 색인)
const SUBST_TABLES: typeof FONT_RULE_SUBSTITUTION_TABLES = FONT_RULE_SUBSTITUTION_TABLES;
const _substMaps = SUBST_TABLES.map(langTable => {
  const map = new Map<string, SubstitutionTarget>();
  for (const [srcName, srcType, dstName, dstType, ruleId] of langTable) {
    const key = srcName + '\0' + srcType;
    if (!map.has(key)) {
      map.set(key, { face: dstName, type: dstType, ruleId });
    }
  }
  return map;
});

export interface FontRuleResolution {
  fontName: string;
  ruleIds: string[];
}

// 해소 결과 캐시
const _resolveCache = new Map<string, FontRuleResolution>();
const GENERIC_FONTS = new Set(['serif', 'sans-serif', 'monospace']);

export interface FontFamilyChainOptions {
  /** 감지 승인 후 확인된 로컬 글꼴 목록. 미지정 시 저장된 감지 결과를 사용한다. */
  confirmedLocalFonts?: readonly string[];
  /** 테스트/레거시 용도: 감지 전 원본 글꼴명을 강제로 포함한다. */
  includeUnconfirmedOriginal?: boolean;
  /** Rust/HWPX가 전달한 문서 선언 substFont. successor 뒤, generic 앞에 둔다. */
  documentFallbackFamilies?: readonly string[];
}

export interface FontFamilyCandidatesDecision {
  candidates: string[];
  ruleIds: string[];
}

const GOVERNMENT_SUCCESSORS_BY_SOURCE = new Map(
  [...new Set(FONT_RULE_GOVERNMENT_SUCCESSORS.map(rule => normalizedFamilyKey(rule.sourceFace)))]
    .map(source => [source, FONT_RULE_GOVERNMENT_SUCCESSORS
      .filter(rule => normalizedFamilyKey(rule.sourceFace) === source)
      .sort((left, right) => left.order - right.order)] as const),
);

let documentFontSubstitutions = new Map<string, string[]>();

function normalizedFamilyKey(fontName: string): string {
  return fontName.normalize('NFC').replace(/\s+/g, ' ').trim().toLocaleLowerCase('en-US');
}

function isGovernmentLegacyFont(fontName: string): boolean {
  return GOVERNMENT_SUCCESSORS_BY_SOURCE.has(normalizedFamilyKey(fontName));
}

/** 새 문서가 열릴 때 이전 문서의 substFont를 남기지 않고 현재 선언으로 교체한다. */
export function setDocumentFontSubstitutions(
  substitutions: ReadonlyArray<readonly [string, string]> | undefined,
): void {
  const next = new Map<string, string[]>();
  for (const entry of substitutions ?? []) {
    if (!Array.isArray(entry) || entry.length !== 2) continue;
    const source = entry[0]?.trim();
    const substitute = entry[1]?.trim();
    if (!source || !substitute) continue;
    const key = normalizedFamilyKey(source);
    const families = next.get(key) ?? [];
    if (!families.some(existing => normalizedFamilyKey(existing) === normalizedFamilyKey(substitute))) {
      families.push(substitute);
    }
    next.set(key, families);
  }
  documentFontSubstitutions = next;
}

/** 엔진이 준 언어별 체인과 대조할 선언 대체 후보를 반환한다. */
export function documentSubstituteFamilies(fontName: string): readonly string[] {
  return documentFontSubstitutions.get(normalizedFamilyKey(fontName)) ?? [];
}

function confirmedFontName(
  candidates: readonly string[],
  confirmedLocalFonts: readonly string[],
): string | null {
  const confirmed = new Map(
    confirmedLocalFonts.map(fontName => [normalizedFamilyKey(fontName), fontName] as const),
  );
  for (const candidate of candidates) {
    const match = confirmed.get(normalizedFamilyKey(candidate));
    if (match) return match;
  }
  return null;
}

function localRecordCssFamily(
  requestedFontName: string,
  record: NonNullable<ReturnType<typeof resolveLocalFont>>,
): string {
  if (normalizedFamilyKey(requestedFontName) === normalizedFamilyKey(record.family)) {
    return record.family;
  }
  const style = normalizedFamilyKey(record.style);
  if (!style || style === 'regular' || style === 'normal' || style === 'r' || style === 'roman') {
    return record.family;
  }
  return record.fullName || record.family;
}

/** 정부상징 legacy 이름에서만 현재 공식 successor의 설치 face를 찾는다. */
export function resolveGovernmentFontSuccessor(
  fontName: string,
  confirmedLocalFonts?: readonly string[],
): string | null {
  return resolveGovernmentFontSuccessorWithRule(fontName, confirmedLocalFonts).fontName;
}

function resolveGovernmentFontSuccessorWithRule(
  fontName: string,
  confirmedLocalFonts?: readonly string[],
): { fontName: string | null; ruleId: string | null } {
  if (!isGovernmentLegacyFont(fontName)) return { fontName: null, ruleId: null };
  const rules = GOVERNMENT_SUCCESSORS_BY_SOURCE.get(normalizedFamilyKey(fontName)) ?? [];
  if (confirmedLocalFonts !== undefined) {
    const confirmed = new Map(
      confirmedLocalFonts.map(candidate => [normalizedFamilyKey(candidate), candidate] as const),
    );
    for (const rule of rules) {
      const match = confirmed.get(normalizedFamilyKey(rule.targetFace));
      if (match) return { fontName: match, ruleId: rule.ruleId };
    }
    return { fontName: null, ruleId: null };
  }
  for (const rule of rules) {
    const record = resolveLocalFont(rule.targetFace);
    if (record) {
      return {
        fontName: localRecordCssFamily(rule.targetFace, record),
        ruleId: rule.ruleId,
      };
    }
  }
  return { fontName: null, ruleId: null };
}

let detectedOSFontIndexCache: Map<string, string> | null = null;
let detectedOSFontIndexSize = -1;

/** 감지 결과가 늘어날 때만 다시 색인해 paint 경로의 문자열 정규화를 줄인다. */
function detectedOSFontIndex(): ReadonlyMap<string, string> {
  const detected = getDetectedOSFonts();
  if (detectedOSFontIndexCache !== null && detectedOSFontIndexSize === detected.size) {
    return detectedOSFontIndexCache;
  }
  const index = new Map<string, string>();
  for (const name of detected) index.set(normalizedFamilyKey(name), name);
  detectedOSFontIndexCache = index;
  detectedOSFontIndexSize = detected.size;
  return index;
}

/**
 * 이 호스트에 실제 face가 있는 이름인지 판정하고 CSS에 쓸 canonical 이름을 돌려준다.
 *
 * 번들 stand-in 웹폰트 등록(`REGISTERED_FONTS`)은 실제 face 보유로 보지 않는다.
 * legacy 이름은 stand-in만 있고 실제 face는 다른 이름으로 설치돼 있기 때문이다.
 */
function installedFaceName(
  fontName: string,
  confirmedLocalFonts: readonly string[] | undefined,
): string | null {
  if (!fontName) return null;
  if (confirmedLocalFonts === undefined) {
    // 같은 family의 한글·영문 프로그램은 단일 OS face로 확정할 수 없다.
    // 이미 로드한 실제 프로그램의 CSS family까지 모호한 이름으로 버리면
    // 원본 OTF를 공급하고도 호환 대체(예: 옥수수 → 돋움)로 그리게 된다.
    if (hasLoadedLocalFontFamily(fontName)) return fontName;
    const record = resolveLocalFont(fontName);
    if (record) return localRecordCssFamily(fontName, record);
  } else {
    const confirmed = confirmedFontName([fontName], confirmedLocalFonts);
    if (confirmed) return confirmed;
    // 호출자가 명시한 목록은 이 호출의 권위 있는 입력이다. 비어 있거나 불일치할 때
    // 이전 문서의 전역 감지 결과를 다시 사용하면 설치되지 않은 face가 선택될 수 있다.
    return null;
  }
  // A width-only presence probe can also see the platform's LastResort font.
  // With an authorized catalog available, an unmatched name is unverified;
  // do not promote that probe to the selected original program.
  if (!getLocalFontState().stored || getLocalFontState().source === 'local-font-access') return null;
  return detectedOSFontIndex().get(normalizedFamilyKey(fontName)) ?? null;
}

/**
 * legacy 이름의 공급이 stand-in 웹폰트뿐일 때, 이 호스트에 설치된 치환 대상 face를 찾는다.
 *
 * `한양중고딕`은 studio 공급 카탈로그에 있으므로 `resolveFont`가 체인을 타지 않고
 * 그대로 돌려준다. 그 공급은 번들 `NotoSansKR-Regular.woff2` stand-in이라 실제로
 * 설치된 `HY중고딕`이 있어도 산세리프로 그려진다. 설치 face를 체인 앞에 둬 이를 막는다.
 */
function installedSubstituteFace(
  fontName: string,
  altType: number,
  langId: number,
  confirmedLocalFonts: readonly string[] | undefined,
): { fontName: string; ruleId: string } | null {
  for (const target of projectedSubstituteTargets(fontName, altType, langId)) {
    const installed = installedFaceName(target.face, confirmedLocalFonts);
    if (installed) return { fontName: installed, ruleId: target.ruleId };
  }
  // [#6263] 치환표 항목에는 altType 조건이 붙어 있다(`한양중고딕`은 `source:2->target:1`
  // 하나뿐). 문서가 같은 legacy 이름을 altType=1 로 선언하면 조회가 통째로 비어, 호스트에
  // `HY견고딕`이 설치돼 있는데도 체인이 곧바로 generic(`Malgun Gothic`)으로 떨어진다
  // (`한양견고딕` altType=1 은 원 이름조차 체인에서 사라진다).
  //
  // 여기서 하는 일은 **설치 face 를 다른 이름으로 찾는 것**뿐이라 선언 altType 과 무관하다.
  // 타입 지정 조회가 비면 타입-무관(0) 탐색으로 한 번 더 본다 — `projectedSubstituteTargets`
  // 가 0 에서 1·2 를 차례로 훑는 기존 규약을 그대로 쓴다.
  if (altType !== 0) {
    for (const target of projectedSubstituteTargets(fontName, 0, langId)) {
      const installed = installedFaceName(target.face, confirmedLocalFonts);
      if (installed) return { fontName: installed, ruleId: target.ruleId };
    }
  }
  return null;
}

function quoteCssFontFamily(fontName: string): string {
  return `"${fontName.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

function formatCssFontFamilies(families: string[]): string {
  return families
    .map(name => GENERIC_FONTS.has(name) ? name : quoteCssFontFamily(name))
    .join(', ');
}

/**
 * CSS `font-family` 목록 문자열을 이름 배열로 가른다. (#6600)
 *
 * 엔진이 주는 체인은 인용 방식이 섞여 있다 — 앞쪽 설치 별칭은 `"..."`, 뒤쪽 generic
 * 체인은 `'...'`, 맨 끝 `sans-serif` 는 무인용이다. 셋을 모두 받는다.
 */
export function parseCssFontFamilyList(familyPart: string): string[] {
  const BACKSLASH = String.fromCharCode(92);
  const out: string[] = [];
  let current = '';
  let quote: string | null = null;
  let escaped = false;
  const flush = () => {
    const name = current.trim();
    if (name) out.push(name);
    current = '';
  };
  for (const ch of familyPart) {
    if (escaped) { current += ch; escaped = false; continue; }
    if (ch === BACKSLASH) { escaped = true; continue; }
    if (quote) {
      if (ch === quote) quote = null;
      else current += ch;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === ',') { flush(); continue; }
    current += ch;
  }
  flush();
  return out;
}

/** 이름 배열을 CSS `font-family` 목록 문자열로 되돌린다. generic 이름은 인용하지 않는다. */
export function formatCssFontFamilyList(families: readonly string[]): string {
  return formatCssFontFamilies([...families]);
}

function pushUniqueFontFamily(families: string[], fontName: string): void {
  const name = fontName.trim();
  if (!name) return;
  const key = name.toLocaleLowerCase('en-US');
  if (families.some(existing => existing.toLocaleLowerCase('en-US') === key)) return;
  families.push(name);
}

/** 기존 요청·별칭의 순서는 보존하고, 빠진 후보를 다음 공통 후보 앞에 넣는다.
 * generic 뒤에 누락 후보를 붙이면 브라우저가 그 후보에 도달하지 못할 수 있다.
 */
export function completeFontFamilyList(incoming: readonly string[], fallback: readonly string[]): string[] {
  const families: string[] = [];
  for (const name of incoming) pushUniqueFontFamily(families, name);
  const key = (name: string) => name.toLocaleLowerCase('en-US');
  for (let index = 0; index < fallback.length; index++) {
    const name = fallback[index].trim();
    if (!name || families.some(existing => key(existing) === key(name))) continue;
    const following = fallback.slice(index + 1).find(candidate =>
      families.some(existing => key(existing) === key(candidate)));
    const position = following === undefined ? families.length
      : families.findIndex(existing => key(existing) === key(following));
    families.splice(position, 0, name);
  }
  return families;
}

function bodyFallbackFamilies(fontName: string): string[] {
  if (GENERIC_FONTS.has(fontName)) return [fontName];
  // KoPub바탕체는 이름에 "바탕체"가 있지만 Windows BatangChe와 달리 비례폭 출판 명조다.
  if (/KoPub\s*바탕(?:체)?|KoPub\s*Batang/i.test(fontName)) {
    return ['Batang', 'AppleMyungjo', 'Noto Serif KR', 'serif'];
  }
  // Monospace 판별
  if (/굴림체|바탕체|gulimche|batangche|coding|courier/i.test(fontName)) {
    return ['GulimChe', 'D2Coding', 'Noto Sans Mono', 'monospace'];
  }
  // Serif 판별
  if (/[바탕명조궁서]|hymjre|times|palatino|georgia|batang|gungsuh/i.test(fontName)) {
    return ['Batang', 'AppleMyungjo', 'Noto Serif KR', 'serif'];
  }
  // Sans-serif (기본)
  return ['Malgun Gothic', 'Apple SD Gothic Neo', 'Noto Sans KR', 'Pretendard', 'sans-serif'];
}

function systemFallbackFamilies(fontName: string): string[] {
  const body = bodyFallbackFamilies(fontName);
  if (GENERIC_FONTS.has(fontName)) return body;
  // 본문 후보 뒤에 공개 문자 기호를 먼저 두어 누락 글자가 컬러 이모지로 바뀌지 않게 한다.
  // 명시적으로 요청한 이모지 face는 호출자가 앞에 보존한다.
  const families: string[] = [];
  for (const name of [...body.slice(0, -1), ...TEXT_SYMBOL_FONT_FAMILIES, 'Segoe UI Emoji', 'Noto Emoji', 'Noto Color Emoji', body.at(-1)!]) {
    pushUniqueFontFamily(families, name);
  }
  return families;
}

/** 원래 선언은 유지하고, 빠진 글리프를 공급할 일반 텍스트 후보를 같은 순서로 준비·소비한다. */
export function ordinaryTextFontFamilies(family: string): string[] {
  const declared = parseCssFontFamilyList(family);
  if (!declared.length) return [];
  const families: string[] = [];
  for (const candidate of [...declared, ...systemFallbackFamilies(declared[0])]) {
    pushUniqueFontFamily(families, candidate);
  }
  return families;
}

/**
 * 폰트 이름을 웹에서 렌더링 가능한 폰트로 치환한다.
 *
 * @param fontName HWP 문서의 폰트 이름
 * @param altType 폰트 타입 (0=알수없음, 1=TTF, 2=HFT)
 * @param langId 언어 카테고리 (0=한국어, 1=영어, ..., 6=사용자)
 * @returns 치환된 폰트 이름
 */
export function resolveFont(fontName: string, altType: number, langId: number): string {
  return resolveFontWithRules(fontName, altType, langId).fontName;
}

export function resolveFontWithRules(
  fontName: string,
  altType: number,
  langId: number,
): FontRuleResolution {
  if (!fontName || REGISTERED_FONTS.has(fontName)) return { fontName, ruleIds: [] };

  const cacheKey = langId + '\0' + fontName + '\0' + altType;
  const cached = _resolveCache.get(cacheKey);
  if (cached !== undefined) return cached;

  const langIdx = (langId >= 0 && langId <= 6) ? langId : 0;
  const substMap = _substMaps[langIdx];

  let name = fontName;
  let type = altType || 0;

  // altType=0이면 TTF(1) 시도, 실패하면 HFT(2) 시도
  if (type === 0) {
    if (substMap.has(name + '\x001')) {
      type = 1;
    } else if (substMap.has(name + '\x002')) {
      type = 2;
    } else {
      const result = { fontName, ruleIds: [] };
      _resolveCache.set(cacheKey, result);
      return result;
    }
  }

  // 체인 추적 (최대 15단계)
  const visited = new Set<string>();
  const ruleIds: string[] = [];
  for (let i = 0; i < 15; i++) {
    if (REGISTERED_FONTS.has(name)) break;

    const key = name + '\0' + type;
    if (visited.has(key)) break;
    visited.add(key);

    const subst = substMap.get(key);
    if (!subst) break;

    name = subst.face;
    type = subst.type;
    ruleIds.push(subst.ruleId);
  }

  const result = { fontName: name, ruleIds };
  _resolveCache.set(cacheKey, result);
  return result;
}

/**
 * CSS font-family 문자열에 전 플랫폼 fallback 체인을 추가한다.
 * Windows → macOS/iOS → Android → 오픈소스 → generic
 */
export function fontFamilyWithFallback(fontName: string): string {
  if (GENERIC_FONTS.has(fontName)) {
    return fontName;
  }
  return formatCssFontFamilies([fontName, ...systemFallbackFamilies(fontName)]);
}

/**
 * 문서 원본 글꼴명을 보존하면서 표시/측정용 CSS font-family chain을 만든다.
 *
 * 순서:
 *   1. rhwp 웹폰트 또는 감지 승인 후 확인된 로컬 글꼴의 canonical CSS family
 *   2. rhwp 웹 대체 글꼴명(resolveFont 결과)
 *   3. OS/system fallback
 *   4. generic fallback
 */
export function fontFamilyChainForDisplay(
  fontName: string,
  altType = 0,
  langId = 0,
  options: FontFamilyChainOptions = {},
): string {
  return formatCssFontFamilies(fontFamilyCandidatesForDisplay(fontName, altType, langId, options));
}

/** Canvas2D 실제 설정과 trace가 공유하는 ordered CSS family 후보다. */
export function fontFamilyCandidatesForDisplay(
  fontName: string,
  altType = 0,
  langId = 0,
  options: FontFamilyChainOptions = {},
): string[] {
  return fontFamilyCandidatesForDisplayWithRules(fontName, altType, langId, options).candidates;
}

export function fontFamilyCandidatesForDisplayWithRules(
  fontName: string,
  altType = 0,
  langId = 0,
  options: FontFamilyChainOptions = {},
): FontFamilyCandidatesDecision {
  if (!fontName) return { candidates: [], ruleIds: [] };
  if (GENERIC_FONTS.has(fontName)) {
    return {
      candidates: [fontName],
      ruleIds: [FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['generic-fallback']],
    };
  }

  const families: string[] = [];
  const ruleIds: string[] = [];
  const confirmedLocalFonts = options.confirmedLocalFonts ?? [];
  const confirmedLocalFontSet = new Set(
    confirmedLocalFonts.map(name => name.toLocaleLowerCase('en-US')),
  );
  const localRecord = options.confirmedLocalFonts === undefined
    ? resolveLocalFont(fontName)
    : null;
  const installedOriginal = installedFaceName(fontName, options.confirmedLocalFonts);
  const originalAllowed =
    options.includeUnconfirmedOriginal === true ||
    REGISTERED_FONTS.has(fontName) ||
    confirmedLocalFontSet.has(fontName.toLocaleLowerCase('en-US')) ||
    installedOriginal !== null;

  if (!localRecord) {
    const substitute = installedOriginal === null
      ? installedSubstituteFace(fontName, altType, langId, options.confirmedLocalFonts)
      : null;
    if (substitute) {
      pushUniqueFontFamily(families, substitute.fontName);
      ruleIds.push(substitute.ruleId);
      ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['paint-substitute']);
    }
  }

  if (localRecord) {
    pushUniqueFontFamily(families, localRecordCssFamily(fontName, localRecord));
    ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['style-fallback']);
  } else if (originalAllowed) {
    // A loaded local program is already the selected face. Do not drop it
    // merely because it is absent from the bundled web-font catalog.
    pushUniqueFontFamily(families, installedOriginal ?? fontName);
    ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['style-fallback']);
  }

  const governmentSuccessor = resolveGovernmentFontSuccessorWithRule(
    fontName,
    options.confirmedLocalFonts,
  );
  if (governmentSuccessor.fontName) {
    pushUniqueFontFamily(families, governmentSuccessor.fontName);
    if (governmentSuccessor.ruleId) ruleIds.push(governmentSuccessor.ruleId);
    ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['official-successor']);
  }

  const resolved = resolveFontWithRules(fontName, altType, langId);
  if (resolved.fontName && resolved.fontName !== fontName) {
    pushUniqueFontFamily(families, resolved.fontName);
    ruleIds.push(...resolved.ruleIds);
    ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['paint-substitute']);
  }

  const documentFallbackFamilies = options.documentFallbackFamilies
    ?? documentFontSubstitutions.get(normalizedFamilyKey(fontName))
    ?? [];
  let documentFallbackAccepted = false;
  for (const documentFallback of documentFallbackFamilies) {
    const localFallback = options.confirmedLocalFonts === undefined
      ? resolveLocalFont(documentFallback)
      : null;
    const confirmedFallback = confirmedFontName([documentFallback], confirmedLocalFonts);
    if (localFallback) {
      pushUniqueFontFamily(
        families,
        localRecordCssFamily(documentFallback, localFallback),
      );
      documentFallbackAccepted = true;
    } else if (confirmedFallback || REGISTERED_FONTS.has(documentFallback)) {
      pushUniqueFontFamily(families, confirmedFallback ?? documentFallback);
      documentFallbackAccepted = true;
    }
  }
  if (documentFallbackAccepted) {
    ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['document-substitution']);
  }

  const fallbackBase = documentFallbackFamilies.at(-1)
    ?? (resolved.fontName && resolved.fontName !== fontName ? resolved.fontName : fontName);
  for (const fallback of systemFallbackFamilies(fallbackBase)) {
    pushUniqueFontFamily(families, fallback);
  }
  ruleIds.push(FONT_RULE_DISPLAY_CHAIN_POLICY_IDS['generic-fallback']);

  return {
    candidates: families,
    ruleIds: [...new Set(ruleIds.filter(Boolean))],
  };
}
